package pkg1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Vehicle
{
	int noOfWheel;
	int noOfPassenger;
	int model;
	String maker;
	
	public Vehicle(int noOfWheel, int noOfPassenger, int model, String maker) 
	{
		this.noOfWheel = noOfWheel;
		this.noOfPassenger = noOfPassenger;
		this.model = model;
		this.maker = maker;
	}

	public String display()
	{
		return "Vehicle Details- \nMaker: "+maker+", Model: "+model+", No. of Passenger: "+noOfPassenger+", no. of wheel: "+noOfWheel;
	}
}

class Car extends Vehicle
{
	int noOfDoors;
	
	public Car(int noOfWheel, int noOfPassenger, int model, String maker,
			int noOfDoors) 
	{
		super(noOfWheel, noOfPassenger, model, maker);
		this.noOfDoors = noOfDoors;
	}

	public String display()
	{
		return super.display()+", no. of doors: "+noOfDoors;
	}
}

class Convertible extends Car
{
	boolean isHoodOpen;

	public Convertible(int noOfWheel, int noOfPassenger, int model,
			String maker, int noOfDoors, boolean isHoodOpen) 
	{
		super(noOfWheel, noOfPassenger, model, maker, noOfDoors);
		this.isHoodOpen = isHoodOpen;
	}

	public String display()
	{
		return super.display()+", hood is: "+(isHoodOpen?"open":"close");
	}
}

class SportCar extends Car
{
	public SportCar(int noOfWheel, int noOfPassenger, int model,
			String maker)
	{
		super(noOfWheel, noOfPassenger, model, maker, 2);
	}
}

public class OverridingProgram4 {

	public static void main(String[] args) throws IOException 
	{
		boolean menuShow = true;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		do
		{
			int noOfWheel;
			int noOfPassenger;
			int model;
			String maker;
			int noOfDoors;
			boolean isHoodOpen;
			
			System.out.println("**********Welcome**********");
			System.out.println("Enter �1�, to  create a Vehicle object.");
			System.out.println("Enter �2�, to  create a Car object.");
			System.out.println("Enter �3�, to  create a Convertible object.");
			System.out.println("Enter �4�, to  create a SportCar object.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your choice: ");

			String inputOption;
			
			inputOption = br.readLine();
			System.out.println("********************************************\n");
			switch(inputOption)
			{
				case "1":System.out.println("Vehicle Object- ");
						System.out.print("Please enter the no. of wheel: ");
						noOfWheel = Integer.parseInt(br.readLine());
						System.out.print("Please enter the no. of passenger/seats: ");
						noOfPassenger = Integer.parseInt(br.readLine());
						System.out.print("Please enter the model no. of vehicle: ");
						model = Integer.parseInt(br.readLine());
						System.out.print("Please enter the maker of vehicle: ");
						maker = br.readLine();
						Vehicle vehicle = new Vehicle(noOfWheel, noOfPassenger, model, maker);
						System.out.println("Vehicle Object is: "+vehicle.display());
						System.out.println("********************************************\n");
						break;

				case "2":System.out.println("Car Object- ");
						System.out.print("Please enter the no. of wheel: ");
						noOfWheel = Integer.parseInt(br.readLine());
						System.out.print("Please enter the no. of passenger/seats: ");
						noOfPassenger = Integer.parseInt(br.readLine());
						System.out.print("Please enter the model no. of car: ");
						model = Integer.parseInt(br.readLine());
						System.out.print("Please enter the maker of car: ");
						maker = br.readLine();
						System.out.print("Please enter the no. of doors: ");
						noOfDoors = Integer.parseInt(br.readLine());
						Car car = new Car(noOfWheel, noOfPassenger, model, maker, noOfDoors);
						System.out.println("Car Object is: "+car.display());
						System.out.println("********************************************\n");
						break;

				case "3":System.out.println("Convertible Car Object- ");
						System.out.print("Please enter the no. of wheel: ");
						noOfWheel = Integer.parseInt(br.readLine());
						System.out.print("Please enter the no. of passenger/seats: ");
						noOfPassenger = Integer.parseInt(br.readLine());
						System.out.print("Please enter the model no. of convertible car: ");
						model = Integer.parseInt(br.readLine());
						System.out.print("Please enter the maker of convertible car: ");
						maker = br.readLine();
						System.out.print("Please enter the no. of doors: ");
						noOfDoors = Integer.parseInt(br.readLine());
						System.out.print("Is hood open? [y/Y]: ");
						String t = br.readLine();
						if(t.equals("y") || t.equals("Y"))
							isHoodOpen = true;
						else
							isHoodOpen = false;
						Convertible convertible = new Convertible(noOfWheel, noOfPassenger, model, maker, noOfDoors, isHoodOpen);
						System.out.println("Convertible Car Object is: "+convertible.display());
						System.out.println("********************************************\n");
						break;

				case "4":System.out.println("Sport Car Object- ");
						System.out.print("Please enter the no. of wheel: ");
						noOfWheel = Integer.parseInt(br.readLine());
						System.out.print("Please enter the no. of passenger/seats: ");
						noOfPassenger = Integer.parseInt(br.readLine());
						System.out.print("Please enter the model no. of sport car: ");
						model = Integer.parseInt(br.readLine());
						System.out.print("Please enter the maker of sport car: ");
						maker = br.readLine();
						SportCar sportCar = new SportCar(noOfWheel, noOfPassenger, model, maker);
						System.out.println("Sport Car Object is: "+sportCar.display());
						System.out.println("********************************************\n");
						break;
						
				case "0":System.out.println("\nThank you for using this system.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
	}

}
