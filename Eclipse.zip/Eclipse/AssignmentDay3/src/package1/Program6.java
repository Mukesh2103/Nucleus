package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Product
{
	private String productID;
	private String name;
	private String categoryID;
	private double unitPrice;
	public Product(String productID, String name, String categoryID,
			double unitPrice) {
		this.productID = productID;
		this.name = name;
		this.categoryID = categoryID;
		this.unitPrice = unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String displayDetails()
	{
		return "Product ID: "+productID+", Name: "+name+", Category ID: "+categoryID+", Unit Price: "+unitPrice;
	}
}

class ElectricProduct extends Product
{
	private double voltageRange;
	private double wattage;
	public ElectricProduct(String productID, String name, String categoryID,
			double unitPrice, double voltageRange, double wattage) {
		super(productID, name, categoryID, unitPrice);
		this.voltageRange = voltageRange;
		this.wattage = wattage;
	}
	public void setWattage(double wattage) {
		this.wattage = wattage;
	}
	public String displayDetails()
	{
		return super.displayDetails()+", Voltage Range: "+voltageRange+", Wattage: "+wattage;
	}
}

public class Program6 {
	public static void main(String[] args) throws IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String productID;
		String name;
		String categoryID;
		double unitPrice;
		double voltageRange;
		double wattage;
		
		ElectricProduct electricProduct;
		
		productID = null;
		name = null;
		categoryID = null;
		unitPrice = 0;
		voltageRange = 0;
		wattage = 0;
		System.out.println("Enter Electric Product Details- ");
		System.out.print("Please enter product id: ");
		productID = br.readLine();
		System.out.print("Please enter product name: ");
		name = br.readLine();
		System.out.print("Please enter product category id: ");
		categoryID = br.readLine();
		System.out.print("Please enter product unit price: ");
		unitPrice = Double.parseDouble(br.readLine());
		System.out.print("Please enter product voltage range: ");
		voltageRange = Double.parseDouble(br.readLine());
		System.out.print("Please enter product wattage: ");
		wattage = Double.parseDouble(br.readLine());
		electricProduct = new ElectricProduct(productID, name, categoryID, unitPrice, voltageRange, wattage);
		System.out.println(electricProduct.displayDetails());
		System.out.println("********************************************************\n");
		

		System.out.print("Change Product Unit Price- Please enter product unit price to change: ");
		unitPrice = Double.parseDouble(br.readLine());
		electricProduct.setUnitPrice(unitPrice);
		System.out.print("Change Product Wattage- Please enter product wattage to change: ");
		wattage = Double.parseDouble(br.readLine());
		electricProduct.setWattage(wattage);
		System.out.println(electricProduct.displayDetails());
		System.out.println("********************************************************\n");
		
	}
}
