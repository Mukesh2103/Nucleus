import pkg1.Default;


public class Default3 {

	public static void main(String[] args) {
		Default d = new Default();	//PrintMethod() is not accessible because method with default
//		d.PrintMethod();			//access modifier is not accessible in the other package.
		System.out.println("Using Other package.");
	}

}
