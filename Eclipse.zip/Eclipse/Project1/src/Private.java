
public class Private {
	
	private String name;		//Private member variable
	private void PrivateMethod()	//Private member function
	{
		System.out.println("Private Method of Private Class");
		System.out.println("Name is :"+name);
	}
	
	public static void main(String[] args) {
		Private p = new Private();
		p.name="Raju Rastogi"; 		//Will work because private member variable
		p.PrivateMethod();			//and function is accessible in the same class
	}								//but not accessible in different class
}
class Private2
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Private p = new Private();
//		p.name="Raju Rastogi"; 		//Will not work because private member variable
//		p.PrivateMethod();			//and function is not accessible in different class
	}
}
