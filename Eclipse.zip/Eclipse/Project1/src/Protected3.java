import pkg1.Protected1;

public class Protected3 {
	public static void main(String[] args)
	{
		Protected1 p = new Protected1();	//ProtectedMethod() is not accessible because method with protected
//		p.ProtectedMethod();			//access modifier is not accessible in the other package until the class is not inheriting.
		System.out.println("Using other package but without inheriting.");
	}
}

class Protected4 extends Protected1 {
	public static void main(String[] args)
	{
		Protected4 p = new Protected4();	//ProtectedMethod() is accessible because method with protected
		p.ProtectedMethod();			//access modifier is accessible in the other package if the class is inheriting.
		System.out.println("Using other package but with inheriting.");
	}
}
