package pkg1;

public class Public3 {
	public static void main(String[] args)
	{
		Public1 p = new Public1();
		p.PublicMethod();		//will work because public method is accessible in all class and all packages.
		System.out.println("Public3 Class");
	}
}
