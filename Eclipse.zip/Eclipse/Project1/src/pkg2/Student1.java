package pkg2;

public class Student1 {
	int stdid;						//member variable Student Id
	String sname;					//member variable Student Name
	
	Student1()						//Constructor with no arguments
	{
		this.stdid = -1;			//Initialize stdid to -1
		this.sname="Not Defined";	//Initialize sname to Not Defined
	}
	
	Student1(int stdid)				//Constructor with single arguments
	{
		this.stdid = stdid;			//Initialize stdid with given value
		this.sname="Not Defined";	//Initialize sname to Not Defined
	}
	
	Student1(String name)			//Constructor with single arguments
	{
		this.stdid = -1;			//Initialize stdid to -1
		sname=name;					//Initialize sname with given value
	}
	
	Student1(int stdid, String sname)//Constructor with single arguments
	{
		this.stdid = stdid;			//Initialize stdid with given value
		this.sname=sname;			//Initialize sname with given value
	}
	
	public void display()			//This method will display Student Id and Student Name
	{
		System.out.println("Student ID: "+stdid);
		System.out.println("Student Name: "+sname);
	}
}
class SMS1
{
	public static void main(String[] args)
	{
		Student1 s1 = new Student1();				//Initialize Student1 reference variable with no
		System.out.println("\nStudent s1 details:");//arguments, call constructor with no arguments.
		s1.display();
		Student1 s2 = new Student1(11);				//Initialize Student1 reference variable with single
		System.out.println("\nStudent s2 details:");//integer arguments, call constructor with single integer arguments.
		s2.display();
		Student1 s3 = new Student1("Rahul");		//Initialize Student1 reference variable with single
		System.out.println("\nStudent s3 details:");//string arguments, call constructor with single string arguments.
		s3.display();
		Student1 s4 = new Student1(101, "Rancho");	//Initialize Student1 reference variable with double
		System.out.println("\nStudent s4 details:");//arguments, call constructor with double arguments.
		s4.display();
	}
}
