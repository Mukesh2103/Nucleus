package pkg2;

public class Student2 {
	int stdid;					//member variable Student Id
	String sname;				//member variable Student Name

	Student2()					//Constructor with no arguments
	{
		this(11);				//This will call the constructor with single integer arguments.
	}
	
	Student2(int stdid)			//Constructor with single arguments
	{
		this("Rancho");			//This will call the constructor with single String arguments.
		this.stdid=stdid;
	}
	
	Student2(String name)		//Constructor with single arguments
	{
		sname=name;				//Initialize sname with given value
	}
	
	public void display()		//This method display Student Id and Student Name
	{
		System.out.println("Student ID: "+stdid);
		System.out.println("Student Name: "+sname);
	}
}
class SMS2
{
	public static void main(String[] args)
	{
		Student2 s1 = new Student2();	//s1 reference variable is created
		System.out.println("\n Student s1 details:");
		s1.display();
	}
}
