package pkg3_20June;

public class ArrayAvg {

	/*
	 * This method will return the average of all the values of array.
	 * The resultant data type is double. 
	 */
	public double CallMethodForArray(int[] arr)
	{
		int sum=0;
		for(int i=0; i<arr.length; i++)
		{
			sum += arr[i];
		}
		return sum/arr.length;
	}
	
	public static void main(String args[])
	{
		ArrayAvg a1 = new ArrayAvg();
		int[] arr = {1,2,3,4,5};		//This line will create the integer array and initialize it.
		for(int i=0; i<arr.length; i++)	//this for loop will print values of array.
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println(a1.CallMethodForArray(arr));		//This line call CallMethodForArray method and print average of values of array.
		for(int i=0; i<arr.length; i++)	//this for loop will print values of array.
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}

}
