package pkg3_20June;

class Exam 
{
	/*
	 * This class has three data member variables
	 */
	String subjectName;
	static int maxMarks = 100;
	double marks;
	
	//This constructor will initialize the data member variables
	public Exam(String subjectName, double marks)
	{
		this.subjectName = subjectName;
		this.marks = marks;
	}
}

class Student2
{
	/*
	 * This class has three data member variables integer, String and type of Exam class
	 */
	int stdid;
	String sname;
	Exam e;
	
	//This constructor will initialize the data member variables
	public Student2(int stdid, String sname, String subjectName, double marks)
	{
		this.stdid = stdid;
		this.sname = sname;
		this.e = new Exam(subjectName, marks);
	}
	
	//This method will display the all the data member variables of Student class
	public void displayDetails()
	{
		System.out.println("Student id: "+stdid+", student name: "+sname+", Exam Name: "+e.subjectName+", Marks: "+e.marks);
	}
}

public class HasARelationship {
	public static void main(String[] args) 
	{
		Student2 s1 = new Student2(11, "Rancho", "Maths", 85);
		System.out.println("Student s1 details-");
		s1.displayDetails();
	}
}
