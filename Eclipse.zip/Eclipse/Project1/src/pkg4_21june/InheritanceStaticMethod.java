package pkg4_21june;

class Account2
{
	public static void withdraw()
	{
		System.out.println("Withdraw Account");
	}
	public static void deposit()
	{
		System.out.println("Deposit Account");
	}
}

class SavingsAccount2 extends Account2
{
	//This function will override the withdraw function of Account class
	public static void withdraw()	
	{
		Account2.withdraw();	//This will call the withdraw function of Account class
		System.out.println("Withdraw SavingsAccount");
	}
	public void calculateInterest()
	{
		System.out.println("Calculate Interest SavingsAccount");
		deposit();		//This will call the deposit function of Account class, deposit function is inherited in SavingAccount class
	}
}

public class InheritanceStaticMethod {
	public static void main(String[] args) 
	{
		SavingsAccount2 sa = new SavingsAccount2();
		sa.withdraw();
		sa.deposit();
		sa.calculateInterest();
	}
}
