package pkg4_21june;

class Account3
{
	public void display()
	{
		System.out.println("Account display method");
	}

	public static void staticDisplay()
	{
		System.out.println("Account staticDisplay method");
	}
	
	public void accountMethod()
	{
		System.out.println("Account Method");
	}
}

class SavingsAccount3 extends Account3
{
	public void display()
	{
		System.out.println("SavingsAccount display method");
	}

	public static void staticDisplay()
	{
		System.out.println("SavingsAccount staticDisplay method");
	}
	
	public void savingsAccountMethod()
	{
		System.out.println("Savings Account Method");
	}
}

class CurrentAccount3 extends Account3
{
	public void display()
	{
		System.out.println("CurrentAccount display method");
	}

	public static void staticDisplay()
	{
		System.out.println("CurrentAccount staticDisplay method");
	}
	
	public void currentAccountMethod()
	{
		System.out.println("Current Account Method");
	}
}
public class UpDownCasting {
	
	/*
	 * This method will accept argument of Account type
	 */
	public void displayDetails(Account3 a)
	{
		System.out.println("displayDetails method");
		a.accountMethod();							//This will call the accountMethod of Account class
		if(a instanceof SavingsAccount3)
		{
			/*
			 * This is not allowed because the variable a is a object of 
			 * SavingAccount and its reference type is Account, So it can not able 
			 * to find the savingAccountMethod in Account Class.
			 * To solve this problem we have to cast Account type to SavingsAccount type.
			 * It is called as DownCasting.
			 */
//			a.savingsAccountMethod();
			SavingsAccount3 sa = (SavingsAccount3)a;	//Downcasting
			sa.savingsAccountMethod();
		}
		if(a instanceof CurrentAccount3)
		{
			/*
			 * This is not allowed because the variable a is a object of 
			 * CurrentAccount and its reference type is Account, So it can not able 
			 * to find the currentAccountMethod in Account Class.
			 * To solve this problem we have to cast Account type to CurrentAccount type.
			 * It is called as DownCasting.
			 */
//			a.currentAccountMethod();
			CurrentAccount3 ca = (CurrentAccount3)a;	//Downcasting
			ca.currentAccountMethod();
		}
	}
	
	public static void main(String[] args) 
	{
		Account3 ac1 = new Account3();
		Account3 ac2 = new SavingsAccount3();	//UpCasting
		Account3 ac3 = new CurrentAccount3();	//UpCasting
		
		/*
		 * The following method will call the non static methods.
		 */
		ac1.display();
		ac2.display();
		ac3.display();
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");

		/*
		 * The following method will call the static methods.
		 */
		ac1.staticDisplay();
		ac2.staticDisplay();
		ac3.staticDisplay();
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		
		UpDownCasting obj = new UpDownCasting();
		obj.displayDetails(ac1);
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		obj.displayDetails(ac2);
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		obj.displayDetails(ac3);
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		
	}
}
