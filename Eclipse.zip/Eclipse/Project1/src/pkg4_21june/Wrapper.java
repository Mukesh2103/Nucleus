package pkg4_21june;

public class Wrapper {
	public static void main(String[] args) 
	{
		//Converting int to Integer
		int a1 = 30;
		Integer i1 = Integer.valueOf(a1);//Converting int to Integer
		Integer j1 = a1;//autoboxing, now compiler will write Integer.valueof(a1) internally
		System.out.println(a1+" "+i1+" "+j1);
		
		//Converting Integer to int
		Integer a2 = new Integer(3);
		int i2 = a2.intValue();//Converting Integer to int
		int j2 = a2;//unboxing, now compiler will write a2.intValue() internally
		System.out.println(a2+" "+i2+" "+j2);
		
		//Converting String to int
		String s = "10";
		int a = Integer.parseInt(s);
		System.out.println(s+" "+a);
	}
}
