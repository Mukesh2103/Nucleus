package pkg5_22june;

abstract class Shape
{
	String shapeName;
	
	public Shape()
	{
		shapeName = "Not Provided";
		System.out.println("No arguments Shape Constructor");
	}
	
	public Shape(String shapeName)
	{
		this.shapeName = shapeName;
		System.out.println("Single arguments Shape Constructor");
	}
	
	abstract void draw();
	
	public void shapeMethod()
	{
		System.out.println(shapeName+" is shape.");
	}
}

class Circle extends Shape
{
	public Circle()
	{
		super("Circle");
		System.out.println("Circle Constructor");
	}
	
	@Override
	void draw() {
		System.out.println(shapeName+" Draw");
	}
	
	public void circleMethod()
	{
		System.out.println("Shape is "+shapeName);
	}
}

class Rectangle extends Shape
{
	public Rectangle()
	{
		super("Rectangle");
		System.out.println("Rectangle Constructor");
	}
	
	@Override
	void draw() {
		System.out.println(shapeName+" Draw");
	}
	
	public void rectangleMethod()
	{
		System.out.println("Shape is "+shapeName);
	}
}

public class AbstractClass {
	
	public static void ShapeDetails(Shape sh)
	{
		sh.draw();
		sh.shapeMethod();
		if(sh instanceof Circle)
			((Circle) sh).circleMethod();
		if(sh instanceof Rectangle)
			((Rectangle) sh).rectangleMethod();
	}
	
	public static void main(String[] args) 
	{
//		Shape s = new Shape();
		
		Shape s = new Circle();
		ShapeDetails(s);
		System.out.println("================================================");
		Shape s1 = new Rectangle();
		ShapeDetails(s1);
	}
}
