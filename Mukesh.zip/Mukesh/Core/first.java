class first
{
	public void x()
	{
		System.out.println("X of First");
	}
	public void y(int n)
	{
		System.out.println("Y of First: Entered num="+n);
	}
	public static void main(String[] args)
	{
		System.out.println("First Program");
		first f = new first();
		f.x();
		f.y(10);
	}
}