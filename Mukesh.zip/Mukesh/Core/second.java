class Second
{
	public void x(int n)
	{
		System.out.println(n+" is number");
	}
	public void x(char n)
	{
		System.out.println(n+" is character");
	}
	public void x(double n)
	{
		System.out.println(n+" is floating value");
	}
	public static void main(String[] args)
	{
		System.out.println("First Program");
		Second s = new Second();
		s.x(10);
		s.x('c');
		s.x(12.5);
	}
}