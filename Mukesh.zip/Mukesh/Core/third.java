class Third
{
	public static void main(String[] args)
	{
		try
		{	
			int num = Integer.parseInt(args[0]);
			System.out.println("Entered Number="+num);
			if(num%2==0)
				System.out.println(num+" is Even");
			else if(num%2==1)
				System.out.println(num+" is Odd");
		}
		catch(Exception e)
		{
			System.out.println("Please enter whole number.");
		}
	}
}