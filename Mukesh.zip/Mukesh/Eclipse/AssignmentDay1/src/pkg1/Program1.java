package pkg1;

public class Program1 
{
	//This function will accept the position number as argument and return the fibonacci number for that position
	public static int fib(int n)
	{
		if(n==1 || n==2)
			return 1;
		else
			return fib(n-1)+fib(n-2);
	}
	
	public static void main(String[] args) 
	{
		int i = 1;
		int res;
		double sum=0;	//This will store the total sum of fibonacci numbers
		System.out.println("The first 20 Fibonacci numbers are: ");
		// This while loop will print the series of 20 fibonacci numbers.
		while(i<=20)
		{
			res = fib(i);
			sum += res;
			System.out.print(res+" ");
			++i;
		}
		System.out.println("\nThe average is "+sum/20);		//This will print the average of first 20 numbers.
	}

}
