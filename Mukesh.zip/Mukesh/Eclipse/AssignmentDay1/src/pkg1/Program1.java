package pkg1;

public class Program1 
{
	
	public static int fib(int n)
	{
		if(n==1 || n==2)
			return 1;
		else
			return fib(n-1)+fib(n-2);
	}
	
	public static void main(String[] args) 
	{
		int i = 1;
		int res;
		double sum=0;
		System.out.println("The first 20 Fibonacci numbers are: ");
		while(i<=20)
		{
			res = fib(i);
			sum += res;
			System.out.print(res+" ");
			++i;
		}
		System.out.println("\nThe average is "+sum/20);
	}

}
