package pkg1;

public class Program2 {

	public static void main(String[] args) 
	{
		// This loop will print the first line of numbers.
		System.out.print("* | ");
		for(int i=1;i<=9;i++)
		{
			System.out.print(i+" ");
		}
		System.out.print("\n-------------------------------");
		
		//This two nested loop will print the desired multiplication table.
		for(int i=1; i<=9; i++)
		{
			System.out.print("\n"+i+" | ");
			for(int j=1; j<=9; ++j)
			{
				System.out.print((i*j)+" ");
			}
		}
	}

}
