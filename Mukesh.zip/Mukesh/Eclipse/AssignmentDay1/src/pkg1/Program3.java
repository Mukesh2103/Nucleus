package pkg1;

import java.util.Scanner;

public class Program3 {
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of students: ");
		int numStudent = sc.nextInt();		//This will accept the no. of students.
		int[] grades = new int[numStudent];	//This will create the integer array grades for students. Whose size is depend on the no. of students.
		int temp;
		double sumOfGrades = 0;
		//This for loop will accept the grade for students.
		for(int i=0; i<numStudent; i++)
		{
			do
			{
				System.out.print("Enter the grade for student "+(i+1)+": ");
				temp = sc.nextInt();
				if(0<=temp && temp<=100)
				{
					grades[i] = temp;
					sumOfGrades += temp;
				}
				else
					System.out.println("Invalid grade, try again... ");
			}
			while(0>temp || temp>100);
		}
		System.out.println("The average is: "+sumOfGrades/grades.length);
		sc.close();
	}
}
