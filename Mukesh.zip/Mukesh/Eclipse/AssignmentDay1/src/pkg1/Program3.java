package pkg1;

import java.util.Scanner;

public class Program3 {
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of students: ");
		int numStudent = sc.nextInt();
		int[] grades = new int[numStudent];
		int temp;
		double sumOfGrades = 0;
		for(int i=0; i<numStudent; i++)
		{
			do
			{
				System.out.print("Enter the grade for student "+(i+1)+": ");
				temp = sc.nextInt();
				if(0<=temp && temp<=100)
				{
					grades[i] = temp;
					sumOfGrades += temp;
				}
				else
					System.out.println("Invalid grade, try again... ");
			}
			while(0>temp || temp>100);
		}
		System.out.println("The average is: "+sumOfGrades/grades.length);
		sc.close();
	}
}
