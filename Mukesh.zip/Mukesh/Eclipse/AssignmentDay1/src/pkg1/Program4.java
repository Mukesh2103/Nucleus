package pkg1;

public class Program4 {
	
	public static int[] copyOf(int[] array)
	{
		int[] resultArray = new int[array.length];
		for(int i=0; i<array.length; ++i)
		{
			resultArray[i] = array[i];
		}
		return resultArray;
	}
	
	public static void main(String[] args) 
	{
		int[] array = {1,2,3,4,5};
		for(int i=0; i<array.length; ++i)
		{
			System.out.print(array[i]+" ");
		}
		System.out.println();
		
		int[] resArray = copyOf(array);
		for(int i=0; i<resArray.length; ++i)
		{
			System.out.print(resArray[i]+" ");
		}
		System.out.println();
		
		resArray[3]=18;
		for(int i=0; i<resArray.length; ++i)
		{
			System.out.println("array[i]: "+array[i]+", resArray[i]: "+resArray[i]);
		}
	}
}
