package pkg1;

public class Program5 {

	public static void main(String[] args) 
	{
		//This two nested for loop will print the desired pattern
		for(int i=1; i<=8; ++i)
		{
			for(int j=1; j<=i; ++j)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}

}
