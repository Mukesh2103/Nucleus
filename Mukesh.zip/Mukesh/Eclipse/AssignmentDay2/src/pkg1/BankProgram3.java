package pkg1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Account
{
	private String memberName;
	final private String accountNumber;
	private double accountBalance;
	
	public Account(String memberName, double accountBalance) 
	{
		this.memberName = memberName;
		this.accountNumber = 10000 + (int)(Math. random ()*89999) + "";
		this.accountBalance = accountBalance;
	}

	public double getAccountBalance() 
	{
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) 
	 {
		this.accountBalance = accountBalance;
	}

	public boolean deposit(double depositAmount)
	{
		accountBalance += depositAmount;
		return true;
	}
}

class SavingAccount extends Account
{
	double interest = 5.0;
	double maxWithdrawLimit;
	double minimumBalance=500;
	
	public SavingAccount(String memberName, double accountBalance, double maxWithdrawLimit) 
	{
		super(memberName, accountBalance);
		this.maxWithdrawLimit = maxWithdrawLimit;
	}

	public double getBalance()
	{
		return (getAccountBalance() * Math.pow((1+(interest/100)), 1));
	}
	
	public boolean withdraw(double withdrawAmount)
	{
		if(withdrawAmount<=getBalance())
		{
			if(withdrawAmount <= maxWithdrawLimit)
			{
				if((getBalance()-withdrawAmount)>=minimumBalance)
				{
					setAccountBalance(getBalance()-withdrawAmount);
					return true;
				}
				else
				{
					System.out.println("After withdrawan amount goes below minimum balance.\nPlease maintain minimum balance.");
					return false;
				}
			}
			else
			{
				System.out.println("Entered amount is greater than maximum withdraw limit.");
				return false;
			}
		}
		else
		{
			System.out.println("Insufficient balance...");
			return false;	
		}
	}
}

class CurrentAccount extends Account
{
	private String tradeLicenceNumber;

	public CurrentAccount(String memberName, double accountBalance,
			String tradeLicenceNumber) 
	{
		super(memberName, accountBalance);
		this.tradeLicenceNumber = tradeLicenceNumber;
	}

	public double getBalance()
	{
		return getAccountBalance();
	}
	
	public boolean withdraw(double withdrawAmount)
	{
		if(withdrawAmount<=getBalance())
		{
			setAccountBalance(getBalance()-withdrawAmount);
			return true;
		}
		else
		{
			System.out.println("Insufficient balance...");
			return false;	
		}
	}
}

public class BankProgram3 
{
	final public static String myConstant="*********************************************************************\n";
	
	public static double getBalanceOfAccount(Account account)
	{
		if(account instanceof SavingAccount)
		{
			return (double)((SavingAccount) account).getBalance();
		}
		else if(account instanceof CurrentAccount)
			return (double)((CurrentAccount) account).getBalance();
		else 
			return 0;
	}
	
	public static void main(String[] args) throws IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Account account = null;
		
		System.out.print("Please enter user name: ");
		String memberName = br.readLine();
		System.out.print("Enter the initial ammount: ");
		double initialAmmount = Double.parseDouble(br.readLine());
		boolean accountOpened = false;
		do
		{
			System.out.println("Create an account- ");
			System.out.println("Enter �1�, to open Saving Account.");
			System.out.println("Enter �2�, to open Current Account.\n(To create a current account trading licence number is required.)");
			System.out.print("Enter your choice: ");
			String accountOption = br.readLine();
			System.out.println(myConstant);
			switch(accountOption)
			{
				case "1": 	System.out.println("Open a saving account- ");
							System.out.print("Enter the maximum withdraw ammount limit: ");
							double maxWithdrawLimit = Double.parseDouble(br.readLine());
							account = new SavingAccount(memberName, initialAmmount, maxWithdrawLimit);
							accountOpened = true;
							System.out.println("Saving Account is created.");
							System.out.println(myConstant);
							break;
							
				case "2": 	System.out.println("Open a current account- ");
							System.out.print("Enter the trading licence number (To create a current account trading licence number is required.): ");
							String tradeLicenceNumber = br.readLine();
							account = new CurrentAccount(memberName, initialAmmount, tradeLicenceNumber);
							accountOpened = true;
							System.out.println("Current Account is created.");
							System.out.println(myConstant);
							break;
							
				default:	System.out.println("**** Error: Invalid Input Option *****\n");
							break;
			}
		}while(!accountOpened);
		
		
		boolean menuShow = true;
		do
		{
			System.out.println("**********Welcome to the Bank**********");
			System.out.println("Enter �1�, to deposit money.");
			System.out.println("Enter �2�, to withdraw money.");
			System.out.println("Enter �3�, to display the account balance.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your choice: ");
			
			String inputOption = br.readLine();
			System.out.println(myConstant);
			
			boolean balanceShow = false;
			String temp = null;
			double previousBalance = 0;
			
			switch(inputOption)
			{
				case "1":System.out.print("Enter the amount to deposit: ");
						double depositAmount = Double.parseDouble(br.readLine());
						System.out.print("Do you want to know the balance [y/Y]: ");
						temp = br.readLine();
						if(temp.equals("y") || temp.equals("Y"))
						{
							previousBalance = getBalanceOfAccount(account);
							balanceShow = true;
						}
						else
							balanceShow = false;
						if(account.deposit(depositAmount))
							System.out.println("Deposited Successfully.");
						else
							System.out.println("Deposit failed.");
						
						if(balanceShow)
						{
							System.out.println("Previous "+previousBalance);
							System.out.println("Deposited Amount: "+depositAmount);
							System.out.println("After Deposition "+(previousBalance + depositAmount));
						}
						System.out.println(myConstant);
						break;

				case "2":System.out.print("Enter the amount to withdraw: ");
						double withdrawAmount = Double.parseDouble(br.readLine());
						System.out.print("Do you want to know the balance [y/Y]: ");
						temp = br.readLine();
						if(temp.equals("y") || temp.equals("Y"))
						{
							previousBalance = getBalanceOfAccount(account);
							balanceShow = true;
						}
						else
							balanceShow = false;
						
						boolean isWithdrawCompleted = false;
						
						if(account instanceof SavingAccount)
							isWithdrawCompleted = ((SavingAccount) account).withdraw(withdrawAmount);
						else if(account instanceof CurrentAccount)
							isWithdrawCompleted = ((CurrentAccount) account).withdraw(withdrawAmount);
						
						if(isWithdrawCompleted)
						{
							System.out.println("Withdrawan Successfully.");
							if(balanceShow)
							{
								System.out.println("Previous "+previousBalance);
								System.out.println("Withdrawan Amount: "+withdrawAmount);
								System.out.println("After Withdrawan "+(previousBalance - withdrawAmount));
							}
						}
						else
							System.out.println("Withdraw failed.");
						
						System.out.println(myConstant);
						break;

				case "3":if(account instanceof SavingAccount)
							System.out.println("Interest is calculated for 1 year with 5% interest anually.");
						System.out.println("Account Balance: "+getBalanceOfAccount(account));
						System.out.println(myConstant);
						break;
						
				case "0":System.out.println("\nThank you for using this system.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
	}
}
