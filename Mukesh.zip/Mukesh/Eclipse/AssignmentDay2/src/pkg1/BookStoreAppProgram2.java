package pkg1;

import java.io.*;
import java.util.Scanner;

class Book
{
	String bookTitle;
	String author;
	String ISBN;
	int numOfCopies;
	
	Book(String bookTitle, String author, String ISBN, int numOfCopies) {
		this.bookTitle = bookTitle;
		this.author = author;
		this.ISBN = ISBN;
		this.numOfCopies = numOfCopies;
	}
	
	void display()
	{
		System.out.println(bookTitle+" - " +author+ " - " +ISBN+ " - " +numOfCopies);
	}
}

class BookStore
{
	Book[] books = new Book[10];
	
	void sell(String bookTitle, int noOfCopies)
	{
		Scanner sc = new Scanner(System.in);
		boolean found = false;
		boolean flag;
		
		for(int i=0; i<books.length; ++i)
		{
			if(books[i] instanceof Book)
			{
				if(bookTitle.equals(books[i].bookTitle))
				{
					flag = true;
					while(flag)
					{
						if(books[i].numOfCopies >= noOfCopies)
						{
							found = true;
							books[i].numOfCopies -= noOfCopies;
							flag = false;
						}
						else
						{
							System.out.print(books[i].bookTitle+" has "+books[i].numOfCopies+" copies.\nPlease enter valid no. of books: ");
							noOfCopies = sc.nextInt();
						}
					}
					
				}
			}
		}
		if(!found)
			System.out.println("Book not found in the store with name "+bookTitle);
		else
			System.out.println("Book sold successfully.");
	}
	
	void order(String isbn, int noOfCopies)
	{
		boolean found = false;
		int pos=0;
		int totalBooks=0;
		for(int i=0; i<books.length; ++i)
		{
			if(books[i] instanceof Book)
			{
				++totalBooks;
				if(isbn.equals(books[i].ISBN))
				{
					found = true;
					books[i].numOfCopies += noOfCopies;
					System.out.println("Book ordered successfully.");
				}
			}
		}
		if(totalBooks<10)
		{
			if(!found)
			{
				System.out.println("Book is not present in the record.");
				Scanner sc = new Scanner(System.in);
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				String bookTitle = "";
				String author = "";
				try 
				{
					System.out.print("Please enter the book title for new entry: ");
					bookTitle = br.readLine();
					System.out.print("Please enter the author name of the book: ");
					author = br.readLine();
				} catch (IOException e) {}
				for(Book book:books)
				{
					if(book instanceof Book)
						++pos;
				}
				books[pos] = new Book(bookTitle, author, isbn, noOfCopies);
			}
			System.out.println("Book ordered successfully.");
		}
		else
		{
			System.out.println("There is space to store only 10 types of books.");
		}
	}
	
	void display()
	{
		boolean flag = false;
		for(Book book:books)
		{
			if(book instanceof Book)
			{
				book.display();
				flag = true;
			}
		}
		if(!flag)
			System.out.println("No Books Found!!!");
	}
}

public class BookStoreAppProgram2
{
	public static void main(String[] args) 
	{
		boolean menuShow = true;
		Scanner sc = new Scanner(System.in);
		BookStore bookStore = new BookStore();
		String isbn;
		String bookTitle="";
		int noOfCopies=0;
		boolean flag;
		boolean againPerform;
		String againInputOption;
		
		bookStore.books[0] = new Book("Harry potter", "J. k. Rowling", "1234567890", 5);
		
		do
		{
			System.out.println("**********Welcome to the Book Store**********");
			System.out.println("Enter �1�, to display the Books: Title � Author � ISBN - Quantity.");
			System.out.println("Enter �2�, to order new books.");
			System.out.println("Enter �3�, to sell books.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your input option: ");

			String inputOption;
			
			inputOption = sc.next();
			System.out.println("********************************************\n");
			switch(inputOption)
			{
				case "1":System.out.println("Available Book Details:");
						bookStore.display();
						System.out.println("********************************************\n");
						break;

				case "2":againPerform = true;
						System.out.println("Order Book:");
						do
						{	
							System.out.print("Please enter isbn no. of book: ");
							isbn = sc.next();
							flag = true;
							do
							{
								System.out.print("Please enter no of copies to order: ");
								if(sc.hasNextInt())
								{
									noOfCopies = sc.nextInt();
									if(noOfCopies <0)
										System.out.println("Invalid no. of books. Books no. should be greater than 0.");
									else
										flag=false;
								}
							}while(flag);
							bookStore.order(isbn, noOfCopies);
							System.out.print("Do you want to order another book? [y/n]: ");
							againInputOption = sc.next();
							if(againInputOption.equals("y") || againInputOption.equals("Y"))
								againPerform = true;
							else
								againPerform = false;
							System.out.println();
						}while(againPerform);
						System.out.println("********************************************\n");
						break;

				case "3":againPerform = true;
						System.out.println("Sell Book:");
						do
						{
							System.out.print("Please enter title of book: ");
							BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
							try {
								bookTitle = br.readLine();
							} catch (IOException e) {}
							flag = true;
							do
							{
								System.out.print("Please enter no of copies to sell: ");
								if(sc.hasNextInt())
								{
									noOfCopies = sc.nextInt();
									if(noOfCopies <0)
										System.out.println("Invalid no. of books. Books no. should be greater than 0.");
									else
										flag=false;
								}
							}while(flag);
							bookStore.sell(bookTitle, noOfCopies);
							System.out.print("Do you want to sell another book? [y/n]: ");
							againInputOption = sc.next();
							if(againInputOption.equals("y") || againInputOption.equals("Y"))
								againPerform = true;
							else
								againPerform = false;
							System.out.println();
						}while(againPerform);
						System.out.println("********************************************\n");
						break;
			
				case "0":System.out.println("\nThank you for using Book Store.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
		sc.close();
	}
}
