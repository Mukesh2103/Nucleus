package pkg1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

//This is the Student class
class Student
{
	String id;
	String name;
	double grade;
	int year;
	
	//This is the constructor with three arguments
	public Student(String id, String name, double grade) 
	{
		this.id = id;
		this.name = name;
		this.grade = grade;
		year = 1;
	}

	//This is the constructor with two arguments
	public Student(String id, String name) 
	{
		this(id, name, 0);		//This will call the constructor with three arguments
	}

	//This is the constructor with single arguments
	public Student(String id) 
	{
		this(id, "Not Given", 0);	//This will call the constructor with three arguments
	}
	
	//This method will display the Student info
	public void display()
	{
		System.out.println("Student Details- Name: "+name+", ID: "+id+", Grade: "+grade);
	}

	//This method will display the Student info if the year of student matched with the passed parameter year
	public void display(int year)
	{
		if(year == this.year)
			System.out.println("Student Details- Name: "+name+", ID: "+id+", Grade: "+grade);
	}
}

public class OverloadingProgram4 {
	
	/*
	 * This method will accept the Student Array parameter and single Student object
	 * and add this single Student object into Student Array and return Student Array.
	 */
	public static Student[] createObject(Student[] students, Student student)
	{
		Student[] temp = new Student[students.length+1];
		for(int i=0; i<students.length; ++i)
		{
			temp[i] = students[i];
		}
		temp[students.length] = student;
		return temp;
	}
	
	public static void main(String[] args) 
	{
		boolean menuShow = true;
		Scanner sc = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		Student[] students = new Student[0];		//This will create the Student Array of length 0.
		String name;
		String id;
		double grade;
		int year;
		
		do
		{
			name = null;
			id = null;
			grade = -1;
			System.out.println("**********Welcome**********");
			System.out.println("�1� � to create a Student object.");
			System.out.println("�2� � to display the student info.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your input option: ");

			String inputOption;
			String option;
			
			inputOption = sc.next();
			System.out.println("********************************************\n");
			
			switch(inputOption)
			{
				case "1":	System.out.println("Student Creation: ");
							try
							{
								System.out.print("Please enter id of student: ");
								id = br.readLine();
								System.out.print("Do you know the name of student? [y/n]: ");
								option = br.readLine();
								if(option.equals("y") || option.equals("Y"))
								{
									System.out.print("Please enter name of student: ");
									name = br.readLine();
								}
								System.out.print("Do you know the grade of student? [y/n]: ");
								option = br.readLine();
								if(option.equals("y") || option.equals("Y"))
								{
									System.out.print("Please enter grade of student: ");
									grade = Double.parseDouble(br.readLine());
								}
								
								if(grade == -1.0 && name == null && id != null)
									students = createObject(students, new Student(id));
								else if(grade == -1. && name!= null && id != null)
									students = createObject(students, new Student(id, name));
								else if(grade != -1 && name!= null && id != null)
									students = createObject(students, new Student(id, name, grade));
							}
							catch(IOException e) {}
							System.out.println("Student object created successfully.");
							System.out.println("********************************************\n");
							break;
			
				case "2":	System.out.println("Student Details: ");
							try
							{
								System.out.print("Do you want to search according to the year of student? [y/n]: ");
								option = br.readLine();
								if(option.equals("y") || option.equals("Y"))
								{
									System.out.print("Please enter year to search:[1/2/3/4] ");
									year = Integer.parseInt(br.readLine());
									for(Student s:students)
									{
										s.display(year);
									}
								}
								else
								{
									for(Student s:students)
									{
										s.display();
									}
								}
							}catch(IOException e) {}
							System.out.println("********************************************\n");
							break;
			
				case "0":	System.out.println("\nThank you for using this application.\nWe will be waiting for you to return.....");
							menuShow = false;
							System.exit(0);
							break;
		
				default:	System.out.println("**** Error: Invalid Input Option *****\n");
							break;
			}
		}while(menuShow);
		sc.close();
			
	}
}
