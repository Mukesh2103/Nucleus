package pkg1;

//This will create Circle class
class Circle
{
	private double radius = 1.0;
	private String colour = "red";
	
	public Circle()
	{
		
	}
	
	public Circle(double r)
	{
		radius = r;
	}
	
	//This method will return radius of Circle
	public double getRadius()
	{
		return radius;
	}

	//This method will return area of Circle
	public double getArea()
	{
		return Math.PI*Math.pow(radius,2);
	}
}

public class Program1 {

	public static void main(String[] args) 
	{
		Circle c1 = new Circle();
		System.out.println("Circle c1 Details- ");
		System.out.println("Radius: "+c1.getRadius()+" and area: "+c1.getArea());

		Circle c2 = new Circle(2.5);
		System.out.println("Circle c2 Details- ");
		System.out.println("Radius: "+c2.getRadius()+" and area: "+c2.getArea());
		
	}

}
