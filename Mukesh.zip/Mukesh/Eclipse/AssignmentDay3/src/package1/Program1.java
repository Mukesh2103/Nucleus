package package1;

import java.io.*;

class Account
{
	private String customerName;
	private String accountNumber;
	private double accountBalance;
	private String typeOfAccount;
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	public String getCustomerName() 
	{
		return customerName;
	}
	public void setAccountNumber() 
	{
		this.accountNumber = 10000 + (int)(Math. random ()*89999) + "";
	}
	public String getAccountNumber() 
	{
		return accountNumber;
	}
	public void setAccountBalance(double accountBalance) 
	{
		this.accountBalance = accountBalance;
	}
	public double getAccountBalance() 
	{
		return accountBalance;
	}
	public void setTypeOfAccount(String typeOfAccount) 
	{
		this.typeOfAccount = typeOfAccount;
	}
	public String getTypeOfAccount() 
	{
		return typeOfAccount;
	}
	public boolean deposit(double depositAmount)
	{
		accountBalance += depositAmount;
		return true;
	}
	public boolean withdraw(double withdrawAmount)
	{
		if(withdrawAmount<=accountBalance)
		{
			accountBalance -= withdrawAmount;
			return true;
		}
		else
		{
			System.out.println("Insufficient balance...");
			return false;	
		}
	}
}


class Sav_acc extends Account
{
	private static boolean compoundInterestFacility = true;
	private static boolean chequeBookFacility = false;
	public void computeAndDepositInterest(double interestRate, double year)
	{
		double newBalance = this.getAccountBalance() * Math.pow((1+(interestRate/100)), year);
		System.out.println("Compond Interest-");
		System.out.println("Interest of "+this.getAccountBalance()+" for "+year+" year at "+interestRate+"% is: "+(newBalance - this.getAccountBalance()));
		this.setAccountBalance(newBalance);
		System.out.println("New Account Balance: "+this.getAccountBalance());
	}
}


class Curr_acc extends Account
{
	private static boolean compoundInterestFacility = false;
	private static boolean chequeBookFacility = true;
	private double minimumBalance;
	public void setMinimumBalance(double minimumBalance) 
	{
		this.minimumBalance = minimumBalance;
	}
	public double getMinimumBalance() 
	{
		return minimumBalance;
	}
	public void checkMinimumBalance()
	{
		if(this.getAccountBalance()<minimumBalance)
		{
			System.out.println("Your account balance is less than the minimum balance.\nYour account balance is "
					+this.getAccountBalance()+" and minimum balance limit is "+minimumBalance
					+"\nPlease maintain minimum balance.");
			System.out.println("You get 100 Rs. penalty.");
			this.setAccountBalance(getAccountBalance()-100);
			System.out.println("Account Balance: "+this.getAccountBalance());
		}
		else
		{
			System.out.println("Your account balance is greater than the minimum balance. There is no penalty.");
		}
	}
}

public class Program1 
{
	final public static String myConstant="*********************************************************************\n";

	public static void main(String[] args) throws IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Account account = null;
		
		String customerName;
		double initialAmmount;
		boolean accountOpened = false;
		do
		{
			System.out.println("Create an account- ");
			System.out.println("Enter �1�, to open Saving Account.");
			System.out.println("Enter �2�, to open Current Account.");
			System.out.print("Enter your choice: ");
			String accountOption = br.readLine();
			System.out.println(myConstant);
			switch(accountOption)
			{
				case "1": 	System.out.println("Open a saving account- ");
							System.out.print("Please enter user name: ");
							customerName = br.readLine();
							System.out.print("Enter the initial ammount: ");
							initialAmmount = Double.parseDouble(br.readLine());
							account = new Sav_acc();
							account.setCustomerName(customerName);
							account.setAccountBalance(initialAmmount);
							account.setAccountNumber();
							account.setTypeOfAccount("Saving");
							accountOpened = true;
							System.out.println("Saving Account is created.");
							System.out.println(myConstant);
							break;
							
				case "2": 	System.out.println("Open a current account- ");
							System.out.print("Please enter user name: ");
							customerName = br.readLine();
							System.out.print("Enter the initial ammount: ");
							initialAmmount = Double.parseDouble(br.readLine());
							account = new Curr_acc();
							account.setCustomerName(customerName);
							account.setAccountBalance(initialAmmount);
							account.setAccountNumber();
							account.setTypeOfAccount("Current");
							((Curr_acc)account).setMinimumBalance(500);
							accountOpened = true;
							System.out.println("Current Account is created.");
							System.out.println(myConstant);
							break;
							
				default:	System.out.println("**** Error: Invalid Input Option *****\n");
							break;
			}
		}while(!accountOpened);
		
		
		boolean menuShow = true;
		do
		{
			System.out.println("**********Welcome to the Bank**********");
			System.out.println("Enter �1�, to Accept deposit from a customer & update the balance");
			System.out.println("Enter �2�, to Display the balance.");
			System.out.println("Enter �3�, to Compute & deposit interest.");
			System.out.println("Enter �4�, to Permit withdrawal & update the balance.");
			System.out.println("Enter �5�, to Check for the minimum balance, impose penalty if necessary & update the balance.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your choice: ");
			
			String inputOption = br.readLine();
			System.out.println(myConstant);
			
			double previousBalance = 0;
			
			switch(inputOption)
			{
				case "1":System.out.print("Enter the amount to deposit: ");
						double depositAmount = Double.parseDouble(br.readLine());
						previousBalance = account.getAccountBalance();
						if(account.deposit(depositAmount))
						{
							System.out.println("Deposited Successfully.");
							System.out.println("Previous "+previousBalance);
							System.out.println("Deposited Amount: "+depositAmount);
							System.out.println("After Deposition "+account.getAccountBalance());
						}
						else
							System.out.println("Deposit failed.");
						System.out.println(myConstant);
						break;

				case "2":System.out.println("Account Balance: "+account.getAccountBalance());
						System.out.println(myConstant);
						break;

				case "3":if(account.getTypeOfAccount().equals("Saving"))
						{
							System.out.print("Please enter interest rate: ");
							double interestRate = Double.parseDouble(br.readLine());
							System.out.print("Please enter the period: ");
							double year = Double.parseDouble(br.readLine());
							((Sav_acc) account).computeAndDepositInterest(interestRate, year);
						}
						else
							System.out.println("Your account type is "+account.getTypeOfAccount()+" account. This functionality is not available for you.");
				System.out.println(myConstant);
						break;
					
				case "4":System.out.print("Enter the amount to withdraw: ");
						double withdrawAmount = Double.parseDouble(br.readLine());
						previousBalance = account.getAccountBalance();
						if(account.withdraw(withdrawAmount))
						{
							System.out.println("Withdrawan Successfully.");
							System.out.println("Previous "+previousBalance);
							System.out.println("Withdrawan Amount: "+withdrawAmount);
							System.out.println("After Withdrawan "+account.getAccountBalance());
						}
						else
							System.out.println("Withdraw failed.");
						System.out.println(myConstant);
						break;

				case "5":if(account.getTypeOfAccount().equals("Current"))
							((Curr_acc) account).checkMinimumBalance();
						else
							System.out.println("Your account type is "+account.getTypeOfAccount()+" account. This functionality is not available for you.");
						System.out.println(myConstant);
						break;
								
				case "0":System.out.println("\nThank you for using this system.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
	}

}
