package package1;

import java.io.*;

//This is the parent class
class Person
{
	private String name;
	private int birthYear;

	public Person(String name, int birthYear) {
		this.name = name;
		this.birthYear = birthYear;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public void setBirthYear(int birthYear) 
	{
		this.birthYear = birthYear;
	}
	public String getName() 
	{
		return name;
	}
	public int getBirthYear() 
	{
		return birthYear;
	}
}

//This is the child class of parent Person
class Student extends Person
{
	private String major;

	public Student(String name, int birthYear, String major) {
		super(name, birthYear);
		this.major = major;
	}
	public void setMajor(String major) 
	{
		this.major = major;
	}
	public String getMajor() 
	{
		return major;
	}
}

//This is the child class of parent Person
class Instructor extends Person
{
	private double salary;
	
	public Instructor(String name, int birthYear, double salary) {
		super(name, birthYear);
		this.salary = salary;
	}
	public void setSalary(double salary) 
	{
		this.salary = salary;
	}
	public double getSalary() 
	{
		return salary;
	}
}

public class Program2 {

	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String name;
		int birthYear;
		String major;
		double salary;
		Person person;
		Student student;
		Instructor instructor;
		try
		{
			name = null;
			birthYear = 0;
			major = null;
			salary = 0;
			
			System.out.println("Create Person Object: ");
			System.out.print("Please enter name of person: ");
			name = br.readLine();
			System.out.print("Please enter year of birth for person: ");
			birthYear = Integer.parseInt(br.readLine());
			person = new Person(name, birthYear);		//This will create object of Person class
			System.out.println("Person Details- \nname: "+person.getName()+" and birth of year: "+person.getBirthYear());
			System.out.println("********************************************************\n");

			name = null;
			birthYear = 0;
			major = null;
			salary = 0;
			
			System.out.println("Create Student Object: ");
			System.out.print("Please enter name of student: ");
			name = br.readLine();
			System.out.print("Please enter year of birth for student: ");
			birthYear = Integer.parseInt(br.readLine());
			System.out.print("Please enter major of student: ");
			major = br.readLine();
			student = new Student(name, birthYear, major);	//This will create object of Student class
			System.out.println("Student Details- \nname: "+student.getName()+", birth of year: "+student.getBirthYear()+" and major: "+student.getMajor());
			System.out.println("********************************************************\n");

			name = null;
			birthYear = 0;
			major = null;
			salary = 0;
			
			System.out.println("Create Instructor Object: ");
			System.out.print("Please enter name of instructor: ");
			name = br.readLine();
			System.out.print("Please enter year of birth for instructor: ");
			birthYear = Integer.parseInt(br.readLine());
			System.out.print("Please enter salary of instructor: ");
			salary = Double.parseDouble(br.readLine());
			instructor = new Instructor(name, birthYear, salary);	//This will create object of Instructor class
			System.out.println("Instructor Details- \nname: "+instructor.getName()+", birth of year: "+instructor.getBirthYear()+" and salary: "+instructor.getSalary());
			System.out.println("********************************************************\n");
		}
		catch(IOException e){}
	}

}
