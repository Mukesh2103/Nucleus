package package1;

import java.io.*;

//This is the parent class
class Employee
{
	String name;
	double salary;
	
	public Employee(String name, double salary) 
	{
		this.name = name;
		this.salary = salary;
	}
}

//This is the child class of parent Employee
class Manager extends Employee
{
	String department;
	
	public Manager(String name, double salary, String department) 
	{
		super(name, salary);
		this.department = department;
	}
	public String toString()
	{
		return "Manager Details- \nName: "+name+", Department: "+department+" and Salary: "+salary;
	}
}

//This is the child class of parent Employee
class Executive extends Manager
{
	public Executive(String name, double salary, String department) 
	{
		super(name, salary, department);
	}
	public String toString()
	{
		return "Executive: Manager Details- \nName: "+name+", Department: "+department+" and Salary: "+salary;
	}
}

public class Program3 {
	public static void main(String[] args) 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String name;
		double salary;
		String department;
		Employee employee;
		Manager manager;
		Executive executive;
		try
		{
			name = null;
			salary = 0;
			department = null;
			System.out.println("Enter Employee Details- ");
			System.out.print("Please enter employee name: ");
			name = br.readLine();
			System.out.print("Please enter employee salary: ");
			salary = Double.parseDouble(br.readLine());
			employee = new Employee(name, salary);			//This will create object of Employee class
			System.out.println("Employee Details- Name: "+employee.name+" and Salary: "+employee.salary);
			System.out.println("********************************************************\n");

			name = null;
			salary = 0;
			department = null;
			System.out.println("Enter Manager Details- ");
			System.out.print("Please enter manager name: ");
			name = br.readLine();
			System.out.print("Please enter manager salary: ");
			salary = Double.parseDouble(br.readLine());
			System.out.print("Please enter manager department: ");
			department = br.readLine();
			manager = new Manager(name, salary, department);	//This will create object of Manager class
			System.out.println(manager.toString());
			System.out.println("********************************************************\n");
			
			executive = new Executive(name, salary, department);
			System.out.println(executive.toString());
			System.out.println("********************************************************\n");
		}
		catch(IOException e){}
	}
}
