package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//This is the parent class
class Student1
{
	private String studentID;
	private String name;
	private String courseID;
	private String sex;
	private String phoneNumber;
	
	public Student1(String studentID, String name, String courseID, String sex,
			String phoneNumber) 
	{
		this.studentID = studentID;
		this.name = name;
		this.courseID = courseID;
		this.sex = sex;
		this.phoneNumber = phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) 
	{
		this.phoneNumber = phoneNumber;
	}
	public String displayDetails()
	{
		return "Student Details- Student ID: "+studentID+", Name: "+name+", Course ID: "+courseID+
				", Sex: "+sex+" Phone Number: "+phoneNumber;
	}
}

//This is the child class of parent Student1
class Hosteller extends Student1
{
	private String hostelName;
	private int roomNumber;
	
	public Hosteller(String studentID, String name, String courseID, 
			String sex, String phoneNumber, String hostelName, int roomNumber) 
	{
		super(studentID, name, courseID, sex, phoneNumber);
		this.hostelName = hostelName;
		this.roomNumber = roomNumber;
	}
	public void setRoomNumber(int roomNumber) 
	{
		this.roomNumber = roomNumber;
	}
	public String displayDetails()
	{
		return "Hosteller "+super.displayDetails()+", Hostel Name: "+hostelName+" and Room No.: "+roomNumber;
	}
	
}

public class Program4 {
	public static void main(String[] args) 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String studentID;
		String name;
		String courseID;
		String sex;
		String phoneNumber;
		String hostelName;
		int roomNumber;
		
		Student1 student;
		Hosteller hosteller;
		try
		{
			studentID = null;
			name = null;
			courseID = null;
			sex = null;
			phoneNumber = null;
			hostelName = null;
			roomNumber = 0;
			System.out.println("Enter Student Details- ");
			System.out.print("Please enter student id: ");
			studentID = br.readLine();
			System.out.print("Please enter student name: ");
			name = br.readLine();
			System.out.print("Please enter student course id: ");
			courseID = br.readLine();
			System.out.print("Please enter student sex: ");
			sex = br.readLine();
			System.out.print("Please enter student phone number: ");
			phoneNumber = br.readLine();
			student = new Student1(studentID, name, courseID, sex, phoneNumber);	//This will create object of Student1 class
			System.out.println(student.displayDetails());
			System.out.println("********************************************************\n");

			studentID = null;
			name = null;
			courseID = null;
			sex = null;
			phoneNumber = null;
			hostelName = null;
			roomNumber = 0;
			System.out.println("Enter Hosteller Student Details- ");
			System.out.print("Please enter student id: ");
			studentID = br.readLine();
			System.out.print("Please enter student name: ");
			name = br.readLine();
			System.out.print("Please enter student course id: ");
			courseID = br.readLine();
			System.out.print("Please enter student sex: ");
			sex = br.readLine();
			System.out.print("Please enter student phone number: ");
			phoneNumber = br.readLine();
			System.out.print("Please enter student hostel name: ");
			hostelName = br.readLine();
			System.out.print("Please enter student room number: ");
			roomNumber = Integer.parseInt(br.readLine());
			hosteller = new Hosteller(studentID, name, courseID, sex, phoneNumber, hostelName, roomNumber);	//This will create object of Hosteller class
			System.out.println(hosteller.displayDetails());
			System.out.println("********************************************************\n");
			

			System.out.print("Change Phone No.- Please enter student phone number to change: ");
			phoneNumber = br.readLine();
			hosteller.setPhoneNumber(phoneNumber);
			System.out.print("Change Room No.- Please enter student room number to change: ");
			roomNumber = Integer.parseInt(br.readLine());
			hosteller.setRoomNumber(roomNumber);
			System.out.println(hosteller.displayDetails());
			System.out.println("********************************************************\n");
		}
		catch(IOException e){}
	}
}
