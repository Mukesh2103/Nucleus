package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Employee5
{
	private String empID;
	private String name;
	private String designation;
	private String projectID;
	private String phoneNumber;
	
	public Employee5(String empID, String name, String designation,
			String projectID, String phoneNumber) 
	{
		this.empID = empID;
		this.name = name;
		this.designation = designation;
		this.projectID = projectID;
		this.phoneNumber = phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) 
	{
		this.phoneNumber = phoneNumber;
	}
	
	public String displayDetails()
	{
		return "Employee ID: "+empID+", Name: "+name+", Designation: "+designation+", Project ID: "+projectID+", Phone Number: "+phoneNumber;
	}
}

class PracticeHead extends Employee5
{
	private String practiceName;
	private int noOfCustomer;
	
	public PracticeHead(String empID, String name, String designation,
			String projectID, String phoneNumber, String practiceName,
			int noOfCustomer) 
	{
		super(empID, name, designation, projectID, phoneNumber);
		this.practiceName = practiceName;
		this.noOfCustomer = noOfCustomer;
	}

	public void setNoOfCustomer(int noOfCustomer) 
	{
		this.noOfCustomer = noOfCustomer;
	}
	
	public String displayDetails()
	{
		return "Project Head Details- Project Head: "+practiceName+", No. of Customer: "+noOfCustomer+", "+super.displayDetails();
	}
}

public class Program5 {
	public static void main(String[] args) 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String empID;
		String name;
		String designation;
		String projectID;
		String phoneNumber;
		String practiceName;
		int noOfCustomer;
		
		PracticeHead practiceHead;
		try
		{
			empID = null;
			name = null;
			designation = null;
			projectID = null;
			phoneNumber = null;
			practiceName = null;
			noOfCustomer = 0;
			System.out.println("Enter Project Head Details- ");
			System.out.print("Please enter employee id: ");
			empID = br.readLine();
			System.out.print("Please enter employee name: ");
			name = br.readLine();
			System.out.print("Please enter employee designation: ");
			designation = br.readLine();
			System.out.print("Please enter project id assigned to employee: ");
			projectID = br.readLine();
			System.out.print("Please enter employee phone number: ");
			phoneNumber = br.readLine();
			System.out.print("Please enter practice head: ");
			practiceName = br.readLine();
			System.out.print("Please enter no. of customers: ");
			noOfCustomer = Integer.parseInt(br.readLine());
			practiceHead = new PracticeHead(empID, name, designation, projectID, phoneNumber, practiceName, noOfCustomer);
			System.out.println(practiceHead.displayDetails());
			System.out.println("********************************************************\n");
			

			System.out.print("Change Phone No.- Please enter employee phone number to change: ");
			phoneNumber = br.readLine();
			practiceHead.setPhoneNumber(phoneNumber);
			System.out.print("Change No. of Customers- Please enter no. of customers to change: ");
			noOfCustomer = Integer.parseInt(br.readLine());
			practiceHead.setNoOfCustomer(noOfCustomer);
			System.out.println(practiceHead.displayDetails());
			System.out.println("********************************************************\n");
		}
		catch(IOException e){}
	}
}
