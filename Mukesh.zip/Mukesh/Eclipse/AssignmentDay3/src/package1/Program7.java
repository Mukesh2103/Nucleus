package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Book
{
	private String bookID;
	private String title;
	private String author;
	private double price;
	
	public Book(String bookID, String title, String author, double price) 
	{
		this.bookID = bookID;
		this.title = title;
		this.author = author;
		this.price = price;
	}
	public void setPrice(double price) 
	{
		this.price = price;
	}
	public String displayDetails()
	{
		return "Book ID: "+bookID+", Title: "+title+", Author: "+author+", price: "+price;
	}
	
}

class Periodical
{
	private String period;
	
	public Periodical(String period)
	{
		this.period = period;
	}
	public void setPeriod(String period) 
	{
		this.period = period;
	}
	public String displayDetails()
	{
		return "Period: "+period;
	}
	
}

public class Program7 {

	public static void main(String[] args) throws IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String bookID;
		String title;
		String author;
		double price;
		String period;
		
		Book book;
		Periodical periodical;
		
		bookID = null;
		title = null;
		author = null;
		price = 0;
		period = null;
		
		System.out.println("Enter Book Details- ");
		System.out.print("Please enter book id: ");
		bookID = br.readLine();
		System.out.print("Please enter book title: ");
		title = br.readLine();
		System.out.print("Please enter book author: ");
		author = br.readLine();
		System.out.print("Please enter book price: ");
		price = Double.parseDouble(br.readLine());
		book = new Book(bookID, title, author, price);
		System.out.println(book.displayDetails());
		System.out.println("********************************************************\n");
		

		System.out.print("Change Book Price- Please enter book price to change: ");
		price = Double.parseDouble(br.readLine());
		book.setPrice(price);
		System.out.println(book.displayDetails());
		System.out.println("********************************************************\n");
		

		System.out.print("Please enter period: ");
		period = br.readLine();
		periodical = new Periodical(period);
		System.out.println(periodical.displayDetails());
		System.out.println("********************************************************\n");
		
		System.out.print("Change Period- Please enter period to change: ");
		period = br.readLine();
		periodical.setPeriod(period);
		System.out.println(periodical.displayDetails());
		System.out.println("********************************************************\n");
	}

}
