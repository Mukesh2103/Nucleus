package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Vehicle
{
	String vehicleNo;
	String model;
	String manufacturer;
	String color;
	
	public Vehicle(String vehicleNo, String model, String manufacturer,
			String color) 
	{
		this.vehicleNo = vehicleNo;
		this.model = model;
		this.manufacturer = manufacturer;
		this.color = color;
	}
	
	public void setColor(String color) 
	{
		this.color = color;
	}
	
	public String displayDetails()
	{
		return "Vehicle Details- Vehicle No.: "+vehicleNo+", Model: "+model+", Manufacturer: "+manufacturer+", Color: "+color;
	}
}

class Truck extends Vehicle
{
	int loadingCapacity;

	public Truck(String vehicleNo, String model, String manufacturer,
			String color, int loadingCapacity) {
		super(vehicleNo, model, manufacturer, color);
		this.loadingCapacity = loadingCapacity;
	}

	public void setLoadingCapacity(int loadingCapacity) 
	{
		this.loadingCapacity = loadingCapacity;
	}
	
	public String displayDetails()
	{
		return "Truck "+super.displayDetails()+", Loading Capacity: "+loadingCapacity;
	}
}

public class Program8 {

	public static void main(String[] args) throws IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String vehicleNo;
		String model;
		String manufacturer;
		String color;
		int loadingCapacity;
		
		Vehicle vehicle;
		Truck truck;
		
		System.out.println("Enter Vehicle Details- ");
		System.out.print("Please enter vehicle no.: ");
		vehicleNo = br.readLine();
		System.out.print("Please enter model of vehicle: ");
		model = br.readLine();
		System.out.print("Please enter manufacturer of vehicle: ");
		manufacturer = br.readLine();
		System.out.print("Please enter color of vehicle: ");
		color = br.readLine();
		vehicle = new Vehicle(vehicleNo, model, manufacturer, color);
		System.out.println(vehicle.displayDetails());
		System.out.println("********************************************************\n");
		

		System.out.print("Change Vehicle Color- Please enter vehicle color to change: ");
		color = br.readLine();
		vehicle.setColor(color);
		System.out.println(vehicle.displayDetails());
		System.out.println("********************************************************\n");

		
		System.out.println("Enter Truck Details- ");
		System.out.print("Please enter truck no.: ");
		vehicleNo = br.readLine();
		System.out.print("Please enter model of truck: ");
		model = br.readLine();
		System.out.print("Please enter manufacturer of truck: ");
		manufacturer = br.readLine();
		System.out.print("Please enter color of truck: ");
		color = br.readLine();
		System.out.print("Please enter loading capacity of truck: ");
		loadingCapacity = Integer.parseInt(br.readLine());
		truck = new Truck(vehicleNo, model, manufacturer, color, loadingCapacity);
		System.out.println(truck.displayDetails());
		System.out.println("********************************************************\n");
		

		System.out.print("Change Vehicle Color- Please enter vehicle color to change: ");
		color = br.readLine();
		truck.setColor(color);
		System.out.print("Change Vehicle Loading Capacity- Please enter loading capacity of truck to change: ");
		loadingCapacity = Integer.parseInt(br.readLine());
		truck.setLoadingCapacity(loadingCapacity);
		System.out.println(truck.displayDetails());
		System.out.println("********************************************************\n");
	}

}
