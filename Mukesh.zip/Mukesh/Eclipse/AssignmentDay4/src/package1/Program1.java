package package1;

public class Program1 {

	public double raiseNumberToPower(double a, double b)
	{
		return Math.pow(a,b);
	}
	
	public static void main(String[] args) 
	{
		System.out.println(Math.pow(12.3,2.5));
	}

}
