package package1;

import java.util.Scanner;

public class Program1 {

	/*
	 * This Method will accept parameter of double type and print power
	 */
	public static void raiseNumberToPower(double a, double b)
	{
		System.out.println("Double power: "+Math.pow(a,b));
	}

	/*
	 * This Method will accept parameter of float type and print power
	 */
	public static void raiseNumberToPower(float a, float b)
	{
		System.out.println("Float power: "+Math.pow(a,b));
	}

	/*
	 * This Method will accept parameter of short type and print power
	 */
	public static void raiseNumberToPower(short a, short b)
	{
		System.out.println("Short power: "+Math.pow(a,b));
	}

	/*
	 * This Method will accept parameter of integer type and print power
	 */
	public static void raiseNumberToPower(int a, int b)
	{
		System.out.println("Integer power: "+Math.pow(a,b));
	}

	/*
	 * This Method will accept parameter of long type and print power
	 */
	public static void raiseNumberToPower(long a, long b)
	{
		System.out.println("Long power: "+Math.pow(a,b));
	}
	
	public static void main(String[] args)
	{
		raiseNumberToPower(5, 3);
		raiseNumberToPower((short)2, (short)3);
		raiseNumberToPower((long)12, (long)3);
		raiseNumberToPower(12.3f, 2.5f);
		raiseNumberToPower(12.3, 2.5);
		
		System.out.println("****************************************************************\n");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter value of base number: ");
		if(sc.hasNextInt())
		{
			int a = sc.nextInt();
			System.out.print("Enter value of power number: ");
			int b = sc.nextInt();
			raiseNumberToPower((int)a, (int)b);
		}
		else if(sc.hasNextShort())
		{
			short a = sc.nextShort();
			System.out.print("Enter value of power number: ");
			short b = sc.nextShort();
			raiseNumberToPower((short)a, (short)b);
		}
		else if(sc.hasNextLong())
		{
			long a = sc.nextLong();
			System.out.print("Enter value of power number: ");
			long b = sc.nextLong();
			raiseNumberToPower((long)a, (long)b);
		}
		else if(sc.hasNextFloat())
		{
			float a = sc.nextFloat();
			System.out.print("Enter value of power number: ");
			float b = sc.nextFloat();
			raiseNumberToPower((float)a, (float)b);
		}
		else if(sc.hasNextDouble())
		{
			double a = sc.nextDouble();
			System.out.print("Enter value of power number: ");
			double b = sc.nextDouble();
			raiseNumberToPower((double)a, (double)b);
		}
		else
			System.out.println("Please enter valid numeric value.");
		
		sc.close();
	}

}
