package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Door
{
	public void doorMethod()
	{
		System.out.println("Door is opened.");
	}
}

class Window
{
	public void windowMethod()
	{
		System.out.println("Window is opened.");
	}
}

class BankAccount
{
	public void bankAccountMethod()
	{
		System.out.println("Bank Account is opened.");
	}
}

class Conversation
{
	public void conversationMethod()
	{
		System.out.println("Conversation is opened.");
	}
}

class Box
{
	public void boxMethod()
	{
		System.out.println("Box is opened.");
	}
}

public class Program2 {
	/*
	 * This Method will accept parameter of Door type and call its method.
	 */
	public static void open(Door door)
	{
		System.out.println("Door- ");
		door.doorMethod();
	}
	/*
	 * This Method will accept parameter of Window type and call its method.
	 */
	public static void open(Window window)
	{
		System.out.println("Window- ");
		window.windowMethod();
	}
	/*
	 * This Method will accept parameter of BankAccount type and call its method.
	 */
	public static void open(BankAccount bankAccount)
	{
		System.out.println("Bank Account- ");
		bankAccount.bankAccountMethod();
	}
	/*
	 * This Method will accept parameter of Conversation type and call its method.
	 */
	public static void open(Conversation conversation)
	{
		System.out.println("Conversation- ");
		conversation.conversationMethod();
	}
	/*
	 * This Method will accept parameter of Box type and call its method.
	 */
	public static void open(Box box)
	{
		System.out.println("Box- ");
		box.boxMethod();
	}
	
	public static void main(String[] args) throws IOException 
	{
		boolean menuShow = true;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		do
		{
			System.out.println("**********Welcome**********");
			System.out.println("Enter �1�, to open a door.");
			System.out.println("Enter �2�, to open a window.");
			System.out.println("Enter �3�, to open a bank account.");
			System.out.println("Enter �4�, to open a conversation.");
			System.out.println("Enter �5�, to open a box.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your input option: ");

			String inputOption;
			
			inputOption = br.readLine();
			System.out.println("********************************************\n");
			switch(inputOption)
			{
				case "1":open(new Door());
						System.out.println("********************************************\n");
						break;

				case "2":open(new Window());
						System.out.println("********************************************\n");
						break;

				case "3":open(new BankAccount());
						System.out.println("********************************************\n");
						break;

				case "4":open(new Conversation());
						System.out.println("********************************************\n");
						break;

				case "5":open(new Box());
						System.out.println("********************************************\n");
						break;

				case "0":System.out.println("\nThank you for using this system.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
	}
}
