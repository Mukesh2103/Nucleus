package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//This is the parent class
class Car
{
	
}
//This is the child of Car class
class SUV extends Car
{
	private static String carName = "TATA SAFARI";
	public static void cars()
	{
		System.out.println("SUV- " +carName);
	}
}
//This is the child of Car class
class SEDAN extends Car
{
	private static String carName = "TATA INDIGO";
	public static void cars()
	{
		System.out.println("SEDAN- " +carName);
	}
}
//This is the child of Car class
class ECONOMY extends Car
{
	private static String carName = "TATA INDICA";
	public static void cars()
	{
		System.out.println("ECONOMY- " +carName);
	}
}
//This is the child of Car class
class MINI extends Car
{
	private static String carName = "TATA NANO";
	public static void cars()
	{
		System.out.println("MINI- " +carName);
	}
}

public class Program3 {
	//This function will create the polymorphism
	public static void modelOfCategory(Car car)
	{
		if(car instanceof SUV)
			SUV.cars();
		else if(car instanceof SEDAN)
			SEDAN.cars();
		else if(car instanceof ECONOMY)
			ECONOMY.cars();
		else if(car instanceof MINI)
			MINI.cars();
	}
	
	public static void main(String[] args) throws IOException 
	{
		boolean menuShow = true;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		do
		{
			System.out.println("**********Welcome**********");
			System.out.println("Please enter the categoris to see available cars [SUV / SEDAN / ECONOMY / MINI]: ");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your choice: ");

			String inputOption;
			
			inputOption = br.readLine();
			System.out.println("********************************************\n");
			switch(inputOption.toUpperCase())
			{
				case "SUV":modelOfCategory(new SUV());
						System.out.println("********************************************\n");
						break;

				case "SEDAN":modelOfCategory(new SEDAN());
						System.out.println("********************************************\n");
						break;

				case "ECONOMY":modelOfCategory(new ECONOMY());
						System.out.println("********************************************\n");
						break;

				case "MINI":modelOfCategory(new MINI());
						System.out.println("********************************************\n");
						break;

				case "0":System.out.println("\nThank you for using this system.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
	}
}
