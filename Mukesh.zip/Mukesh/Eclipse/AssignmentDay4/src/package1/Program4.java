package package1;

import java.io.*;

public class Program4 {
	
	/*
	 * This method will print the volume of cube
	 */
	public static double volume(double side)
	{
		return (side*side*side);
	}
	/*
	 * This method will print the volume of cylinder
	 */
	public static double volume(double radius, double height)
	{
		return (Math.PI*radius*radius*height);
	}
	/*
	 * This method will print the volume of rectangle
	 */
	public static double volume(double length, double breadth, double height)
	{
		return (length*breadth*height);
	}
	
	public static void main(String[] args) throws IOException 
	{
		boolean menuShow = true;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		do
		{
			System.out.println("**********Welcome**********");
			System.out.println("Enter �1�, to calculate area of cube.");
			System.out.println("Enter �2�, to calculate area of cylinder.");
			System.out.println("Enter �3�, to calculate area of rectangle.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your input option: ");

			String inputOption;
			
			inputOption = br.readLine();
			System.out.println("********************************************\n");
			switch(inputOption)
			{
				case "1":System.out.println("Cube- ");
						System.out.print("Please enter the side of cube: ");
						Double side = Double.parseDouble(br.readLine());
						System.out.println("Area of cube: "+volume(side));
						System.out.println("********************************************\n");
						break;

				case "2":System.out.println("Cylinder- ");
						System.out.print("Please enter the base radius of cylinder: ");
						Double radius = Double.parseDouble(br.readLine());
						System.out.print("Please enter the height of cylinder: ");
						Double height = Double.parseDouble(br.readLine());
						System.out.println("Area of cube: "+volume(radius, height));
						System.out.println("********************************************\n");
						break;

				case "3":System.out.println("Rectangle- ");
						System.out.print("Please enter the length of rectangle: ");
						Double lendth = Double.parseDouble(br.readLine());
						System.out.print("Please enter the breadth of rectangle: ");
						Double breadth = Double.parseDouble(br.readLine());
						System.out.print("Please enter the height of rectangle: ");
						Double height1 = Double.parseDouble(br.readLine());
						System.out.println("Area of cube: "+volume(lendth, breadth, height1));
						System.out.println("********************************************\n");
						break;

				case "0":System.out.println("\nThank you for using this system.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);	//This will exit the system and terminate the program execution
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
	}

}
