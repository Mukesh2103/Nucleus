package package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

abstract class Worker
{
	String name;
	double salaryRate;
	
	public Worker(String name, double salaryRate)
	{
		this.name = name;
		this.salaryRate = salaryRate;
	}
	
	public abstract double computePay(int hours);
}

class HourlyWorker extends Worker
{
	public HourlyWorker(String name, double salaryRate) 
	{
		super(name, salaryRate);
	}
	public double computePay(int hours)
	{
		if(hours<=40)
			return (salaryRate*hours);
		else
			return ((salaryRate*40) + ((salaryRate/2) * (hours-40)));
	}
}

class SalariedWorker extends Worker
{
	public SalariedWorker(String name, double salaryRate) 
	{
		super(name, salaryRate);
	}
	public double computePay(int hours)
	{
		return salaryRate*hours;
	}
}

public class Program5 {

	public static void main(String[] args) throws IOException 
	{
		boolean menuShow = true;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String name;
		double salaryRate;
		Worker worker;
		
		do
		{
			name = null;
			salaryRate = 0;
			
			System.out.println("**********Welcome**********");
			System.out.println("Enter �1�, to calculate the payable salary amount of hourly worker.");
			System.out.println("Enter �2�, to calculate the payable salary amount of salaried worker.");
			System.out.println("Enter �0�, to exit the system.");
			System.out.print("Please enter your choice: ");

			String inputOption;
			
			inputOption = br.readLine();
			System.out.println("********************************************\n");
			switch(inputOption)
			{
				case "1":System.out.println("Hourly Worker- ");
						System.out.print("Please enter the name of worker: ");
						name = br.readLine();
						System.out.print("Please enter the salary rate of worker: ");
						salaryRate = Double.parseDouble(br.readLine());
						worker = new HourlyWorker(name, salaryRate);
						System.out.print("Please enter the no. of hours worked by worker: ");
						int hours = Integer.parseInt(br.readLine());
						System.out.println("Payable salary amount is: "+worker.computePay(hours));
						System.out.println("********************************************\n");
						break;

				case "2":System.out.println("Salaried Worker- ");
						System.out.print("Please enter the name of worker: ");
						name = br.readLine();
						System.out.print("Please enter the salary rate of worker: ");
						salaryRate = Double.parseDouble(br.readLine());
						worker = new SalariedWorker(name, salaryRate);
						System.out.println("Payable salary amount is: "+worker.computePay(40));
						System.out.println("********************************************\n");
						break;
						
				case "0":System.out.println("\nThank you for using this system.\nI will be waiting for you to return.....");
						menuShow = false;
						System.exit(0);
						break;
				
				default:System.out.println("**** Error: Invalid Input Option *****\n");
						break;
			}
		}
		while(menuShow);
	}

}
