package com.nucleus.dao;

import com.nucleus.domain.Customer;

public interface CustomerDAO 
{
	public void saveCustomer(Customer customer);
}
