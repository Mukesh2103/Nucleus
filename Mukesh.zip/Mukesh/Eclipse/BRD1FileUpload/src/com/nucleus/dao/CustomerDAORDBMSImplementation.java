package com.nucleus.dao;

import com.nucleus.domain.Customer;

public class CustomerDAORDBMSImplementation implements CustomerDAO
{

	@Override
	public void saveCustomer(Customer customer) 
	{
		
	}

}
