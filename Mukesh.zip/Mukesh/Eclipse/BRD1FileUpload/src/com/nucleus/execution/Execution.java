package com.nucleus.execution;

import java.util.List;

import com.nucleus.domain.Customer;
import com.nucleus.filehandler.FileHandler;

public class Execution {

	public static void main(String[] args) 
	{	
		String fileName = "File1";
		String fileLocation = "D:/Mukesh/BRD-File Upload/Test Cases/File1.txt";
		char rejectionLevel = 'R';
		
		FileHandler fileHandler = new FileHandler();
		List<Customer> customerList = fileHandler.readFromFile(fileLocation);
		
		System.out.println(customerList);
		
	}

}
