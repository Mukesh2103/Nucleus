package com.nucleus.filehandler;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.domain.Customer;

public class FileHandler 
{
	
	public List<Customer> readFromFile(String fileLocation)
	{
		List<Customer> customerList = new ArrayList<>();
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try 
		{
			fileReader = new FileReader(fileLocation);
			bufferedReader = new BufferedReader(fileReader);
			String line = bufferedReader.readLine();
			while(line != null)
			{
//				System.out.println(line);
				String[] customerData = line.split("~", -1);
				/*for(String s:customerData)
					System.out.println(s);
				System.out.println("*****************************");*/
				
				Customer customer = new Customer();
				customer.setCustomerCode(customerData[0]);
				customer.setCustomerName(customerData[1]);
				customer.setCustomerAddress1(customerData[2]);
				customer.setCustomerAddress2(customerData[3]);
				customer.setCustomerPinCode(customerData[4]);
				customer.setEmailAddress(customerData[5]);
				customer.setContactNumber(customerData[6]);
				customer.setPrimaryContactPerson(customerData[7]);
				customer.setRecordStatus(customerData[8].charAt(0));
				customer.setActiveInactiveFlag(customerData[9].charAt(0));
				customer.setCreatedDate(customerData[10]);
				customer.setCreatedBy(customerData[11]);
				customer.setModifiedDate(customerData[12]);
				customer.setModifiedBy(customerData[13]);
				customer.setAuthorizedDate(customerData[14]);
				customer.setAuthorizedBy(customerData[15]);
				
				customerList.add(customer);
				
				line = bufferedReader.readLine();
			}
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				bufferedReader.close();
				fileReader.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		return customerList;
	}
}
