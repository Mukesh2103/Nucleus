package program1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Program1 {

	public static void main(String[] args) throws NumberFormatException, IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int bestPlayerCount = 0;
		double sum=0;
		double avg = 0;
		System.out.print("Please enter the count of players: ");
		int playerCount = Integer.parseInt(br.readLine());
		if(playerCount==0)
			System.out.println("No. of players is: "+playerCount+" \nNot Possible.");
		else if(playerCount>0)
		{
			System.out.println("Please enter player details: ");
			String playerDetails = br.readLine();
			playerDetails = playerDetails.trim();
			playerDetails = playerDetails.substring(1, (playerDetails.length()-2));
//			System.out.println(playerDetails);
			String[] playerScores = playerDetails.split(", ");
			for(String playerScore:playerScores)
			{
//				System.out.println(playerScore);
				String[] scores = playerScore.split("");
				sum = 0;
				/*for(int i=0; i<scores.length;++i)
				{
					System.out.println(scores[i]);
				}*/
				for(String score:scores)
				{
					sum += Double.parseDouble(score);
				}
//				System.out.println(sum+" "+scores.length);
				avg = sum/scores.length;
//				System.out.println(avg);
				if(avg>=5)
					++bestPlayerCount;
			}
			
			System.out.println("********************************************");
			System.out.println("No. of best players: "+bestPlayerCount);
		}
		else
			System.out.println("no of players should be positive.");
	}

}
