package program2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Program2 {
	
	public static int position=0;
	
	public static int[] myArray(int[] arr, int pos)
	{
		if(arr[pos+1]==(arr[pos]+1) && arr[pos+2]==(arr[pos]+2))
		{
			int[] result = new int[arr.length-2];
			for(int i=0; i<pos; ++i)
			{
				result[i] = arr[i];
			}
			result[pos] = arr[pos+1];
			for(int i=pos+3; i<arr.length; ++i)
			{
				result[i-2] = arr[i];
			}
			position = 0;
			return result;
		}
		else
		{
			return arr;
		}
	}

	public static void main(String[] args) throws IOException 
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please provide input: ");
		String input = br.readLine();
		input = input.trim();
		int matchesPlayed = Integer.parseInt(input.split(":")[0]);
		String scores = input.split(":")[1];
		scores = scores.substring(1, (scores.length()-1));
		String[] playerScores = scores.split(", ");
		if(1<=matchesPlayed && matchesPlayed<=10000)
		{
			int[] playerScoresInInt = new int[playerScores.length]; 
			for(int i=0; i<playerScores.length; ++i)
			{
				playerScoresInInt[i] = Integer.parseInt(playerScores[i]);
			}
			for(position=0; position<playerScoresInInt.length-1; ++position)
			{
				playerScoresInInt = myArray(playerScoresInInt, position);
			}
			
			String output="{";
			for(int i=0; i<playerScoresInInt.length; ++i)
			{
				if(i==(playerScoresInInt.length-1))
					output += playerScoresInInt[i]+"}";
				else
					output += playerScoresInInt[i]+", ";
			}
			System.out.println(output);
		}
		else
			System.out.println("Invalid no. of matches played. \nNo. of matches should be between 1 and 10000");
	}

}
