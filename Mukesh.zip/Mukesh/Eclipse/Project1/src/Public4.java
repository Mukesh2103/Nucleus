import pkg1.Public1;


public class Public4 {
	public static void main(String[] args)
	{
		Public1 p = new Public1();
		p.PublicMethod();		//will work because public method is accessible in all class and all packages.
		System.out.println("Public4 Class");
	}
}
