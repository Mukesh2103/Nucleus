package pkg1;

public class Default {
	void PrintMethod()			//Method with default access modifier
	{
		System.out.println("Print Method of Default Class.");
	}
}
class Default2
{
	public static void main(String[] args)
	{
		Default d = new Default();
		d.PrintMethod();		//PrintMethod() is accessible because method with default
	}							//access modifier is accessible within the same package.
}
