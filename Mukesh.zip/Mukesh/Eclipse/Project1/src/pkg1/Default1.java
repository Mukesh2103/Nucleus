package pkg1;

public class Default1 {
	public static void main(String[] args)
	{
		Default d = new Default();	//PrintMethod() is accessible because method with default
		d.PrintMethod();			//access modifier is accessible within the same package.
		System.out.println("Using Same package.");
	}
}
