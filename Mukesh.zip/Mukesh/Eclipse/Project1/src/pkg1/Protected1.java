package pkg1;
public class Protected1 {
	protected void ProtectedMethod()		//Protected Method
	{
		System.out.println("Protected Method of Protected1.");
	}
}
class Protected2 {
	public static void main(String[] args)
	{
		Protected1 p = new Protected1();	//ProtectedMethod() is accessible because method with protected
		p.ProtectedMethod();				//access modifier is accessible within the same package and same file.
		System.out.println("Using Same package and same file.");
	}
}
