package pkg1;

public class Protected5 {
	public static void main(String[] args)
	{
		Protected1 p = new Protected1();	//ProtectedMethod() is accessible because method with protected
		p.ProtectedMethod();				//access modifier is accessible within the same package and same file.
		System.out.println("Using Same package and other file.");
	}
}
