package pkg1;

public class Public1 {
	public void PublicMethod()		//Public method
	{
		System.out.println("Public Method of Public1.");
	}
}
class Public2
{
	public static void main(String[] args)
	{
		Public1 p = new Public1();
		p.PublicMethod();		//will work because public method is accessible in all class and all packages.
		System.out.println("Public2 Class");
	}
}
