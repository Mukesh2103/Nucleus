package pkg2;

public class Student {
	int stdid;		//member variable Student Id
	String sname;	//member variable Student Name
	public void display()		//This method display Student Id and Student Name
	{
		System.out.println("Student ID: "+stdid);
		System.out.println("Student Name: "+sname);
	}
}
class StudentManagementSystem
{
	public static void main(String[] args)
	{
		Student s1 = new Student();
		System.out.println("\n Student s1 details:");
		s1.display();		//This print 0 and NULL because stdid has 0 as default value and sname has NULL as default value.
		s1.stdid=101;		//This store 101 in stdid
		s1.sname="Rancho";	//This store Rancho in sname
		System.out.println("\n Student s1 details:");
		s1.display();
		Student s2 = new Student();
		s2.stdid=105;
		s2.sname="Raju";
		System.out.println("\n Student s2 details:");
		s2.display();
		
		s1=s2;				//s1 starting to point values of s2, previously it points to s1.
		System.out.println("\n Student s1 details:");
		s1.display();
		System.out.println("\n Student s2 details:");
		s2.display();
	}
}
