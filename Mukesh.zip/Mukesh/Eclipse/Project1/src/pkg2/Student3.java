package pkg2;

import java.util.Scanner;

public class Student3 {
	private int stdid;				//member variable Student Id
	private String sname;			//member variable Student Name
	static int studentCount = 0;	//static member variable to count students
	
	Student3()
	{
		++this.studentCount;		//Increase the no. of students
	}
	
	Student3(int stdid, String sname)
	{
		this.stdid = stdid;			//Initialize stdid with given value
		this.sname=sname;			//Initialize sname with given value
		++this.studentCount;		//Increase the no. of students
	}

	public void display()			//This method will display Student Id and Student Name
	{
		System.out.println("Student ID: "+stdid);
		System.out.println("Student Name: "+sname);
	}
	
	public void set()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter student id: ");
		this.stdid=sc.nextInt();
		System.out.print("Please enter student name: ");
		this.sname=sc.next();
	}
	
	public static void totalStudent()		//This method will display the total no. of students.
	{
		System.out.println("\nTotal no. of students: "+Student3.studentCount);
	}
}

class SMS3
{
	public static void main(String[] args)
	{
		Student3 s1 = new Student3();
		System.out.println("\nStudent s1 details:");
		s1.display();
		s1.set();
		s1.display();
		s1.totalStudent();

		Student3.totalStudent();

		Student3 s2 = new Student3(101, "Rahul");
		System.out.println("\nStudent s2 details:");
		s2.display();
		s2.totalStudent();

		Student3.totalStudent();
		
		System.out.println(Student3.studentCount);
	}
}