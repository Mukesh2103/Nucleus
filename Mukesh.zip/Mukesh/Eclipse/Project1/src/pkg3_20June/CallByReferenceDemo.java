package pkg3_20June;

class Employee
{
	/*
	 * This class has three data member variables
	 */
	int empid;
	String ename;
	int salary;

	//This constructor will initialize the data member variables
	public Employee(int empid, String ename, int salary)
	{
		this.empid = empid;
		this.ename = ename;
		this.salary = salary;
	}

	//This method will display the all the data member variables
	public void displayEmpDetails()
	{
		System.out.println(empid+" "+ename+" "+salary);
	}
}

public class CallByReferenceDemo {

	/*
	 * This method will accept Employee data type variables
	 */
	public void displayEmpSalarySlip(Employee emp)
	{
		emp.displayEmpDetails();
		emp.ename = "employee2";
	}
		
	public static void main(String[] args) 
	{
		Employee e1 = new Employee(1,"emp1", 7878);
		CallByReferenceDemo c1 = new CallByReferenceDemo();
		c1.displayEmpSalarySlip(e1);
		e1.displayEmpDetails();
	}
}
