package pkg3_20June;

public class CallByValRefDemo {
	
	/* 
	 * This function accept one integer value and increase it by one and print it.
	 */
	public void CallByValueMethod(int a)
	{
		a++;
		System.out.println(a);
	}
	
	/*
	 * This function will accept one string value and create substring of the given string 
	 * of length 5 character starting from begining and print it.
	 */
	public void CallMethodForString(String temp)
	{
		temp = temp.substring(0,5);
		System.out.println(temp);
	}
	
	/*
	 * This method will accept integer array and change the first element of array
	 * with another value and print the values of array.
	 */
	public void CallMethodForArray(int[] arr)
	{
		arr[0]=6;
		for(int i=0; i<arr.length; i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	
	public static void main(String args[])
	{
		// we first create the instance of CallByValRefDemo class to call its all methods.
		CallByValRefDemo c1 = new CallByValRefDemo();
		
		int a = 100;			//create integer variable a and initialize with 100
		c1.CallByValueMethod(a);	//This line call the CallByValueMethod
		System.out.println(a);		//It will again print the value of a.
		
		String temp = "Hello World!";	//this line will create String variable and initialize with "Hello World!"
		c1.CallMethodForString(temp);	//This line will call the CallMethodForString method
		System.out.println(temp);		//This line will again print the string variable
		
		int[] arr = {1,2,3,4,5};		//This line will create the integer array and initialize it.
		for(int i=0; i<arr.length; i++)	//this for loop will print values of array.
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		c1.CallMethodForArray(arr);		//This line will call the CallMethodForArray.
		for(int i=0; i<arr.length; i++)	//this for loop will print values of array.
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}

}
