package pkg3_20June;

public class Student1 {
	
	/*
	 * Member variable student id and student name
	 */
	int stdid;
	String sname;
	
	// Default constructor
	public Student1() {}
	
	//Constructor with parameters and it will initialize the data member variables
	public Student1(int stdid, String sname) 
	{
		this.stdid = stdid;
		this.sname = sname;
	}

	/*
	 * This method return the student id data member
	 */
	public int getStdid() {
		return stdid;
	}

	/*
	 * This method will set the student id data member
	 */
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}

	/*
	 * This method return the student name data member
	 */
	public String getSname() {
		return sname;
	}

	/*
	 * This method will set the student name data member
	 */
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	
}
class MainClass
{
	public static void main(String[] args) 
	{
		Student1 s1 = new Student1();	// It will create s1 instance of Student1 class.
		s1.setStdid(10);				//this will set stdid of s1
		s1.setSname("Rancho");			//this will set sname of s1
		System.out.println("Student s1 Details-  Student id: "+s1.getStdid()+" Student name: "+s1.getSname());
		Student1 s2 = new Student1(21, "Rahul");	//It will create s2 instance of Student1 class.
		System.out.println("Student s2 Details-  Student id: "+s2.getStdid()+" Student name: "+s2.getSname());
	}
}
