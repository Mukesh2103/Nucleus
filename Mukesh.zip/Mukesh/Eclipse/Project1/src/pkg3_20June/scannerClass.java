package pkg3_20June;
//This line will import Scanner class
import java.util.Scanner;

public class scannerClass {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter your name: ");
		String name = sc.next();	//This line will accept entered string name and store it in name String variable.  
		System.out.print("Please enter your age: ");
		int age = sc.nextInt();		//This line will accept entered integer age and store it in age integer variable.
		System.out.println("Your name: "+name+" and your age: "+age);
		sc.close();
	}
}
