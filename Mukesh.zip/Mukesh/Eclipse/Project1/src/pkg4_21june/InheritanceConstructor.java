package pkg4_21june;

class Account1
{
	/*
	 * Default Constructor
	 */
	public Account1()
	{
		System.out.println("Account Constructor");
	}
	/*
	 * Constructor with single arguments 
	 */
	public Account1(int num)
	{
		System.out.println("Account Constructor with integer parameter: "+num);
	}
}

class SavingsAccount1 extends Account1
{
	/*
	 * Default Constructor
	 */
	public SavingsAccount1()
	{
//		super();	//This will call the default parent constructor
		super(50);	//This will call the parent constructor with one arguments	
		System.out.println("SavingsAccount Constructor");
	}
}

public class InheritanceConstructor {
	public static void main(String[] args) 
	{
		SavingsAccount1 sa = new SavingsAccount1();
	}
}
