package pkg4_21june;

class Account
{
	int a=10;
	int b=20;
	public void withdraw()
	{
		System.out.println("Withdraw Account");
	}
}

class SavingsAccount extends Account
{
	int a=1;
	public void withdraw()
	{
		super.withdraw();	//This will call the withdraw function of parent class
		System.out.println("Withdraw SavingsAccount");
	}
	public void withdraw(float money)
	{
		System.out.println("Withdraw SavingsAccount- Money: "+money);
	}
	public void calculateInterest()
	{
		System.out.println("Calculate Interest");
	}
	public void printValues()
	{
		System.out.println("Values of a: "+a+", b:"+b+" and values of a of parent class- a: "+super.a);
	}
}

public class InheritanceDemo1 {

	public static void main(String[] args) {
		SavingsAccount sa = new SavingsAccount();
		sa.withdraw();
		sa.withdraw(70.5f);
		sa.calculateInterest();
		sa.printValues();
	}

}
