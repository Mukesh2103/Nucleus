package pkg4_21june;

public class VarArgs {
	
	/*
	 * This method will only accept variable arguments of String type
	 */
	public static void display(String... values)
	{
		System.out.println("Display method invoked");
		for(String s:values)
		{
			System.out.print(s+" ");
		}
		System.out.println(); 
	}
	
	/*
	 * This method will accept one integer argument and variable arguments of String type
	 * Order of arguments is first integer will come and then variable arguments
	 */
	public static void display(int num, String... values)
	{
		System.out.println("Display method invoked");
		System.out.println("Entered number is: "+num);
		for(String s:values)
		{
			System.out.print(s+" ");
		}
		System.out.println();
	}
	
	/*
	 * This is not allowed because variable arguents must be last arguments
	 */
//	public static void display(String... values, int numValues)
//	{
//		
//	}

	/*
	 * This is not allowed because there is only one variable arguments is allowed
	 */
//	public static void display(int... numValues, String... values)
//	{
//		
//	}

	/*
	 * This method will only accept variable arguments of Integer type
	 */
	public static void show(int... values)
	{
		System.out.println("Display method invoked");
		for(int i:values)
		{
			System.out.print(i+" ");
		}
		System.out.println();
	}
	
	public static void main(String[] args) 
	{
		display();
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		display("Hello");
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		display("My","name","is","varargs");
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		display(100,"My","name","is","varargs1");
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
		show(1,2,3,4,5);
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=");
	}
}
