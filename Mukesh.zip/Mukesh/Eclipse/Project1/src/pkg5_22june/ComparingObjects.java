package pkg5_22june;

class Student
{
	int age;
	String name;
	
	public Student(int age, String name)
	{
		this.age = age;
		this.name = name;
	}
	
	//This method will override the equals method of object class and return true if the values of these objects is same.
	public boolean equals(Student student)
	{
		if(age == student.age && name == student.name)
			return true;
		else
			return false;
	}
}

public class ComparingObjects {

	public static void main(String[] args) 
	{
		Student s1 = new Student(21, "mukesh");
		Student s2 = new Student(21, "mukesh");
		System.out.println(s1==s2);			//This will return false because it only compare the address points by these reference variable.
		System.out.println(s1.equals(s2));	//This will return true because it compare the values of these student objects.
	}

}
