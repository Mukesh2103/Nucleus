package pkg5_22june;

class Student
{
	int age;
	String name;
}

public class ComparingObjects {

	public static void main(String[] args) 
	{

	}

}
