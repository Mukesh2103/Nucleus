package pkg5_22june;

public class ComparingStrings {
	public static void main(String[] args) 
	{
		String str1 = "Hi";
		String str2 = "Hi";
		System.out.println(str1==str2);
		System.out.println(str1.equals(str2));

		String str3 = new String("Hi");
		String str4 = new String("Hi");
		System.out.println(str3==str4);
		System.out.println(str3.equals(str4));
		
		System.out.println(str2==str3);
		System.out.println(str2.equals(str3));
		System.out.println(str3.equals(str2));
	}
}
