package pkg5_22june;

public class ComparingStrings {
	public static void main(String[] args) 
	{
		String str1 = "Hi";
		String str2 = "Hi";
		System.out.println(str1==str2);		//This will return true because str1 and str2 points the same "Hi" in string pool.
		System.out.println(str1.equals(str2));	//This will return true because it compare the values points by these objects.

		String str3 = new String("Hi");
		String str4 = new String("Hi");
		System.out.println(str3==str4);			//This will return false because it compare the address points by str3 and str4.
		System.out.println(str3.equals(str4));	//This will return true because it compare the values points by these objects.
		
		System.out.println(str2==str3);
		System.out.println(str2.equals(str3));
		System.out.println(str3.equals(str2));
	}
}
