package pkg5_22june;

class Demo
{
	final int i = 10;
	final int j;
	
	public Demo()
	{
		j=20;
	}
	
	public void printValues()
	{
		System.out.println("i: "+i+", j: "+j);
	}
	
	public void myMethod()
	{
		final int a = 35;
//		j = 30;
		System.out.println("try to define final variable in method definition");
	}
}

public class FinalVariables {

	public static void main(String[] args) {
		Demo d = new Demo();
		d.printValues();
		d.myMethod();
	}

}
