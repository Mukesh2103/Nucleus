package pkg5_22june;

class Demo
{
	final int i = 10;	//Final variables can only be initialized either at the time of declaration or inside the constructor
	final int j;		//This type of declaration is called the blank declaration.
	
	public Demo()
	{
		j=20;
	}
	
	public void printValues()
	{
		System.out.println("i: "+i+", j: "+j);
	}
	
	public void myMethod()
	{
		final int a = 35;	// This is the final variable of local type or whose scope is local
//		j = 30;			// Value of final variable can not be modified.
		System.out.println("try to define final variable in method definition");
	}
}

public class FinalVariables {

	public static void main(String[] args) {
		Demo d = new Demo();
		d.printValues();
		d.myMethod();
	}

}
