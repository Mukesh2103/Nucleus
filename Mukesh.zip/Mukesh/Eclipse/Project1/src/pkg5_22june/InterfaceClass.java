package pkg5_22june;

/*
 * This is the user defined interface
 */
interface Device
{
	String name = "Device";		//public static final
}

//This is the second interface which inherits the Device interface
interface ElectronicDevice extends Device
{
	int a = 10;					//public static final
	void brightnessControl();	//public abstract
}

//This class is implementing the ElectronicDevice interface
class Computer implements ElectronicDevice
{
	public void brightnessControl() 
	{
		System.out.println("Computer Brightness Control");
	}
}

public class InterfaceClass 
{
	public static void main(String[] args) 
	{
		ElectronicDevice ed = new Computer();	//We can create the reference variable of interface but we can not create the object of interface
		ed.brightnessControl();
		System.out.println(ElectronicDevice.a);
		System.out.println(ElectronicDevice.name);
	}
}
