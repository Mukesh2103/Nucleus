package pkg6_25june;

public class ExceptionHandlingDemo1 {
	public static void myMethod() throws ArithmeticException, NullPointerException
	{							//throws keyword specifies the Exceptions and we do not have to use try catch block for checked exception during writing code or compilation.
		int a = 10/10;
		System.out.println(a);
		String str = null;
		System.out.println(str.length());
		int[] arr = new int[2];
		arr[2] = 5;
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Calculation: ");
		myMethod();
		/*try
		{
			myMethod();
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
			System.out.println("Number is not divisible by 0.");
			e.printStackTrace();
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
			System.out.println("String is not initialized. String is null.");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("Main parent exception class.");
			e.printStackTrace();
		}*/
		System.out.println("End");
	}
}
