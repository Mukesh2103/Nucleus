package pkg6_25june;

class MyException extends Exception		//This is the user defined exception. We can create our own Exception by extending Exception class.
{
	public void show()
	{
		System.out.println("Divisor should be greater than 0.");
	}
}

public class ExceptionHandlingDemo4 {
	public static void main(String[] args) {
		int a = 10;
		int b = 0;
		try
		{
			if(b==0)
				throw new MyException();	//This will throw the user defined exception explicitly.
			else
				System.out.println("result: "+(a/b));
		}
		catch(MyException e)
		{
			e.show();
		}
	}
}
