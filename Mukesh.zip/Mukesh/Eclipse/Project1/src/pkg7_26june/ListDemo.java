package pkg7_26june;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

class Student1
{
	int age;
	String name;
	
	public Student1(int age, String name)
	{
		this.age = age;
		this.name = name;
	}
	
	public String toString()
	{
		return "["+age+", "+name+"]";
	}
}

public class ListDemo {
	
	public static void displayList(List list)
	{
		System.out.println(list);
	}

	public static void main(String[] args) 
	{
		List list, list1;
		
		list= new ArrayList();
		list.add(10);
		list.add(15);
		list.add(99.5);
		list.add(14.5);
		list.add("Hello");
		System.out.println(list);
		list.add(2, "Bye");
		System.out.println(list);
		
		list1 = new ArrayList();
		list1.add("new");
		list1.add("list");
		list1.add(5);
		System.out.println("List: "+ list);
		System.out.println("New List: "+ list1);
		list.add(list1);
		System.out.println("After adding new list to previous list. \nList: "+ list);
		list.add(2, list1);
		System.out.println("After adding new list to previous list at position 2. \nList: "+ list);
		System.out.println("***************************************************");
		
		list.remove("Bye");
		System.out.println("After removing 'Bye' List: "+ list);
		/*list.remove(15);
		System.out.println("After removing 'Bye' List: "+ list);*/
		list.remove(new Integer(15));
		System.out.println("After removing '15' List: "+ list);
		Integer element = 10;
		list.remove(element);
		System.out.println("After removing '10' List: "+ list);
		
		System.out.println("\nDisplay method: ");
		displayList(list1);
		
		System.out.println("Adding object of Student class: ");
		list.add(new Student1(21, "mukesh"));
		displayList(list);
		
		
		System.out.println("\n*******************************LinkedList************************************\n");
		
		list= new LinkedList();
		list.add(10);
		list.add(15);
		list.add(99.5);
		list.add(14.5);
		list.add("Hello");
		System.out.println(list);
		list.add(2, "Bye");
		System.out.println(list);
		
		list1 = new ArrayList();
		list1.add("new");
		list1.add("list");
		list1.add(5);
		System.out.println("List: "+ list);
		System.out.println("New List: "+ list1);
		list.add(list1);
		System.out.println("After adding new list to previous list. \nList: "+ list);
		list.add(2, list1);
		System.out.println("After adding new list to previous list at position 2. \nList: "+ list);
		System.out.println("***************************************************");
		
		list.remove("Bye");
		System.out.println("After removing 'Bye' List: "+ list);
		/*list.remove(15);
		System.out.println("After removing 'Bye' List: "+ list);*/
		list.remove(new Integer(15));
		System.out.println("After removing '15' List: "+ list);
		Integer element1 = 10;
		list.remove(element1);
		System.out.println("After removing '10' List: "+ list);
		
		System.out.println("\nDisplay method: ");
		displayList(list1);
		
		System.out.println("Adding object of Student class: ");
		list.add(new Student1(21, "mukesh"));
		displayList(list);

		
		
		System.out.println("\n*******************************Vector************************************\n");
		
		list= new Vector();
		list.add(10);
		list.add(15);
		list.add(99.5);
		list.add(14.5);
		list.add("Hello");
		System.out.println(list);
		list.add(2, "Bye");
		System.out.println(list);
		
		list1 = new Vector();
		list1.add("new");
		list1.add("list");
		list1.add(5);
		System.out.println("List: "+ list);
		System.out.println("New List: "+ list1);
		list.add(list1);
		System.out.println("After adding new list to previous list. \nList: "+ list);
		list.add(2, list1);
		System.out.println("After adding new list to previous list at position 2. \nList: "+ list);
		System.out.println("***************************************************");
		
		list.remove("Bye");
		System.out.println("After removing 'Bye' List: "+ list);
		/*list.remove(15);
		System.out.println("After removing 'Bye' List: "+ list);*/
		list.remove(new Integer(15));
		System.out.println("After removing '15' List: "+ list);
		Integer element2 = 10;
		list.remove(element2);
		System.out.println("After removing '10' List: "+ list);
		
		System.out.println("\nDisplay method: ");
		displayList(list1);

		
		System.out.println("Adding object of Student class: ");
		list.add(new Student1(21, "mukesh"));
		displayList(list);
	}

}
