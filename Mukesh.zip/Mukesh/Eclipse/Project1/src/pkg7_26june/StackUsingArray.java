package pkg7_26june;

import java.util.Scanner;

public class StackUsingArray {

	public static int[] stackPush(int[] stack, int element)
	{
		int[] newStack = new int[stack.length+1];
		for(int i=0; i<stack.length; ++i)
		{
			newStack[i] = stack[i];
		}
		newStack[stack.length] = element;
		return newStack;
	}

	public static int[] stackPop(int[] stack)
	{
		int[] newStack = new int[stack.length-1];
		for(int i=0; i<(stack.length-1); ++i)
		{
			newStack[i] = stack[i];
		}
		System.out.println("Popped element is: "+stack[stack.length-1]);
		return newStack;
	}
	
	public static String displayStack(int[] stack)
	{
		String result="[";
		for(int i=0; i<stack.length; ++i)
		{
			if(i==(stack.length-1))
				result += stack[i]+"]";
			else if(i<(stack.length-1))
				result +=stack[i]+", ";
		}
		return result;
	}
	
	public static String displayArray(int[] array)
	{
		String result = "Array: ";
		for(int i:array)
		{
			result += i+"  ";
		}
		return result;
	}
	
	public static int[] insertIntoArrayAtPosition(int[] array, int element, int pos)
	{
		for(int i=(array.length-1); i>=pos; --i)
		{
			array[i] = array[i-1];
		}
		array[pos] = element;
		return array;
	}
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int[] stack = {1, 2, 3, 4, 5};
		System.out.println("Current Stack: "+displayStack(stack));
		System.out.print("Enter any integer number to add into stack: ");
		int element = sc.nextInt();
		stack = stackPush(stack, element);
		System.out.println("After adding "+element+" into stack. \nStack: "+displayStack(stack));
		stack = stackPop(stack);
		System.out.println("After poping the element from stack. \nStack: "+displayStack(stack));
		stack = stackPop(stack);
		System.out.println("After poping the element from stack. \nStack: "+displayStack(stack));
		
		System.out.println("***********************************************************************\n");
		int[] array = new int[10];
		array[0]=1;
		array[1]=2;
		array[2]=3;
		array[3]=4;
		array[4]=5;
		System.out.println(displayArray(array));
		System.out.print("Enter integer element to insert: ");
		element = sc.nextInt();
		System.out.print("Enter position in array to insert in array: ");
		int pos = sc.nextInt();
		array = insertIntoArrayAtPosition(array, element, pos);
		System.out.println(displayArray(array));
	}

}
