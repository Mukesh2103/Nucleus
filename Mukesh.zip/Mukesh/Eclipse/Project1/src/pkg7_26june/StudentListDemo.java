package pkg7_26june;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

class Student
{
	String id;
	int age;
	String name;
	
	public Student(String id, int age, String name)
	{
		this.id = id.toUpperCase();
		this.age = age;
		this.name = name;
	}
	
	public String toString()
	{
		return "[Id: "+id+", Age: "+age+", Name: "+name+"]";
	}
}

public class StudentListDemo {
	
	static BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
	static List studentsRecord = new ArrayList();
	
	public static List addStudent() throws IOException
	{
		System.out.print("Enter name of Student: ");
		String name = bufferedReader.readLine();
		System.out.print("Enter id of student: ");
		String id = bufferedReader.readLine();
		System.out.print("Enter age of student: ");
		int age = Integer.parseInt(bufferedReader.readLine());
		studentsRecord.add(new Student(id, age, name));
		return studentsRecord;
	}
	
	public static void displayAll()
	{
		if(studentsRecord.size()>0)
		{
			System.out.println("Student dtails: ");
			for(int i=0; i<studentsRecord.size(); ++i)
			{
				System.out.println(studentsRecord.get(i));
			}
		}
		else
			System.out.println("No Student Records Found!!!");
	}
	
	public static void display() throws IOException
	{
		System.out.println("Please enter id of student to show his details: ");
		String id = bufferedReader.readLine();
		boolean found = false;
		if(studentsRecord.size()>0)
		{
			for(int i=0; i<studentsRecord.size(); ++i)
			{
				if(id.equals(((Student) studentsRecord.get(i)).id))
				{
					found = true;
					System.out.println("Student dtails: ");
					System.out.println(studentsRecord.get(i));
				}
			}
			if(!found)
			{
				System.out.println("There is no student in the record with id: "+id);
			}
		}
		else
			System.out.println("No Student Records Found!!!");
	}
	
	public static void update() throws IOException
	{
		System.out.print("Please enter id of student to edit his details: ");
		String id = bufferedReader.readLine();
		boolean found = false;
		if(studentsRecord.size()>0)
		{
			for(int i=0; i<studentsRecord.size(); ++i)
			{
				if(id.equals(((Student) studentsRecord.get(i)).id))
				{
					found = true;
					Student foundStudent = (Student) studentsRecord.get(i);
					System.out.println("Student dtails: ");
					System.out.println(studentsRecord.get(i));
					String temp;
					String name;
					String stdId;
					int age;
					
					temp = null;
					System.out.print("Do you want to edit name [y/Y]: ");
					temp = bufferedReader.readLine();
					if(temp.equalsIgnoreCase("y"))
					{
						System.out.print("Please enter name to edit: ");
						name = bufferedReader.readLine();
						foundStudent.name = name;
					}

					temp = null;
					System.out.print("Do you want to edit id [y/Y]: ");
					temp = bufferedReader.readLine();
					if(temp.equalsIgnoreCase("y"))
					{
						System.out.print("Please enter id to edit: ");
						id = bufferedReader.readLine();
						foundStudent.id = id;
					}

					temp = null;
					System.out.print("Do you want to edit age [y/Y]: ");
					temp = bufferedReader.readLine();
					if(temp.equalsIgnoreCase("y"))
					{
						System.out.print("Please enter age to edit: ");
						age = Integer.parseInt(bufferedReader.readLine());
						foundStudent.age = age;
					}
				}
			}
			if(!found)
			{
				System.out.println("There is no student in the record with id: "+id);
			}
		}
		else
			System.out.println("No Student Records Found!!!");
	}
	
	public static void delete() throws IOException
	{
		System.out.print("Please enter id of student to delete his details: ");
		String id = bufferedReader.readLine();
		boolean found = false;
		if(studentsRecord.size()>0)
		{
			for(int i=0; i<studentsRecord.size(); ++i)
			{
				if(id.equals(((Student) studentsRecord.get(i)).id))
				{
					found = true;
					studentsRecord.remove(i);
				}
			}
			if(!found)
			{
				System.out.println("There is no student in the record with id: "+id);
			}
		}
		else
			System.out.println("No Student Records Found!!!");
	}

	public static void main(String[] args) throws IOException 
	{
//		List studentsRecord = new ArrayList();
		/*displayAll();
		addStudent();
		addStudent();
		addStudent();
		displayAll();
		display();
		displayAll();
		update();
		displayAll();
		delete();
		displayAll();*/
		
		do
		{
			System.out.println("*****************************Student System*****************************");
			System.out.println("Enter '1': to add Student.");
			System.out.println("Enter '2': to display all Students record.");
			System.out.println("Enter '3': to display Student record by id.");
			System.out.println("Enter '4': to delete Student.");
			System.out.println("Enter '5': to update Student.");
			System.out.println("Enter '6': to exit the system.");
			System.out.print("Please enter your option: ");
			
			String inputOption = bufferedReader.readLine();
			System.out.println("***************************************************************\n");
			switch(inputOption)
			{
				case "1":addStudent();
						System.out.println("***************************************************************\n");
						break;
				
				case "2":displayAll();
						System.out.println("***************************************************************\n");
						break;

				case "3":display();
						System.out.println("***************************************************************\n");
						break;

				case "4":delete();
						System.out.println("***************************************************************\n");
						break;

				case "5":update();
						System.out.println("***************************************************************\n");
						break;

				case "6":System.out.println("Thank you for using this system.");
						System.exit(0);
						break;
						
				default: System.out.println("*********Invalid Option*********");
						break;
			}
		}while(true);
	}

}
