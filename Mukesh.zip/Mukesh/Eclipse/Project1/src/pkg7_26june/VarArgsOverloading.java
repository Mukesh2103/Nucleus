package pkg7_26june;

public class VarArgsOverloading {

	public static void myMethod(int... arguments)
	{
		System.out.println("Variable arguments of type int");
		for(int argument:arguments)
		{
			System.out.print(argument+" ");
		}
		System.out.println();
	}

	public static void myMethod(int arguments)
	{
		System.out.println("Arguments of type int: "+arguments);
	}

	public static void myMethod(Integer arguments)
	{
		System.out.println("Arguments of type Integer: "+arguments);
	}
	
	public static void main(String[] args) 
	{
		myMethod(1,2,3);
		myMethod(1);
		myMethod(new Integer(10));
	}

}
