package pkg8_27june;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileHandlingDemo {

	public void saveToFile(String name)
	{
		FileWriter fileWriter = null;
		PrintWriter printWriter = null;
		try 
		{
//			fileWriter = new FileWriter("myfile.txt");			//This will create the new file if file is not present, 
																//Otherwise it will overwrite the data of file.
			fileWriter = new FileWriter("myfile.txt", true);	//This will create the new file if file is not present,
																//Otherwise it will append the inserted data int present file.
			printWriter = new PrintWriter(fileWriter);
			printWriter.write(name+"\n");
			printWriter.flush();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				printWriter.close();
				fileWriter.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	public void readFromFile()
	{
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try 
		{
			fileReader = new FileReader("myfile.txt");
			bufferedReader = new BufferedReader(fileReader);
			System.out.println("File Content: ");
			String line = bufferedReader.readLine();
			while(line != null)
			{
				System.out.println(line);
				line = bufferedReader.readLine();
			}
			System.out.println("\n");
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				bufferedReader.close();
				fileReader.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) 
	{
		FileHandlingDemo fileHandlingDemo = new FileHandlingDemo();
		fileHandlingDemo.saveToFile("Hello");
		fileHandlingDemo.readFromFile();
		fileHandlingDemo.saveToFile("Hello123");
		fileHandlingDemo.readFromFile();
		fileHandlingDemo.saveToFile("Bye");
		fileHandlingDemo.readFromFile();
	}

}
