package pkg8_27june;

class Student1
{
	String id;
	String name;
	String college;
	double marks;
	
	public Student1(String id, String name, String college, double marks) 
	{
		this.id = id;
		this.name = name;
		this.college = college;
		this.marks = marks;
	}
	
	public String toString() 
	{
		return "Id: "+id+", Name: "+name+", College: "+college+", Marks: "+marks;
	}
}

class StudentDatabaseList
{
	
}


public class StudentDatabaseListDemo
{

	public static void main(String[] args) 
	{

	}

}
