package pkg8_27june;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

class Student
{
	String id;
	String name;
	String college;
	double marks;
	
	public Student(String id, String name, String college, double marks) 
	{
		this.id = id;
		this.name = name;
		this.college = college;
		this.marks = marks;
	}
	
	public String toString() 
	{
		return id+" "+name+" "+college+" "+marks;
	}
}

class FileHandler {

	public void saveToFile(String studentData)
	{
		FileWriter fileWriter = null;
		PrintWriter printWriter = null;
		try 
		{
			fileWriter = new FileWriter("src/pkg8_27june/DatabaseFiles/StudentData.txt", true);	
			printWriter = new PrintWriter(fileWriter);
			printWriter.write(studentData+"\n");
			printWriter.flush();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				printWriter.close();
				fileWriter.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	public List<Student> readFromFile()
	{
		List<Student> studentDataList = new ArrayList<>();
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try 
		{
			fileReader = new FileReader("src/pkg8_27june/DatabaseFiles/StudentData.txt");
			bufferedReader = new BufferedReader(fileReader);
			System.out.println("File Content: ");
			String line = bufferedReader.readLine();
			while(line != null)
			{
				System.out.println(line);
				String[] studentDatas = line.split(" ");
				studentDataList.add(new Student(studentDatas[0], studentDatas[1], studentDatas[2], Double.parseDouble(studentDatas[3])));
				line = bufferedReader.readLine();
			}
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				bufferedReader.close();
				fileReader.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		return studentDataList;
	}
}

public class StudentDatabaseSystem {

	public static void main(String[] args) throws IOException 
	{
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		FileHandler fileHandler = new FileHandler();
		List<Student> studentData;
		do
		{
			System.out.println("*****************************Student File System*****************************");
			System.out.println("Enter '1': to create Student and store into the file.");
			System.out.println("Enter '2': to fetch record from Students File and Show it.");
			System.out.println("Enter '3': to exit the system.");
			System.out.print("Please enter your option: ");
			
			String inputOption = bufferedReader.readLine();
			System.out.println("***************************************************************\n");
			switch(inputOption)
			{
				case "1":System.out.print("Enter the no. of student to insert record: ");
						int studentCount = Integer.parseInt(bufferedReader.readLine());
						System.out.println();
						String id;
						String name;
						String college;
						double marks;
						Student student = null;
						studentData = new ArrayList<Student>();
						for(int i=0; i<studentCount; ++i)
						{
							id = null;
							name = null;
							college = null;
							marks = 0;
							System.out.println("Enter details of "+(1+1)+" student- ");
							System.out.print("Enter id of student: ");
							id = bufferedReader.readLine();
							System.out.print("Enter name of Student: ");
							name = bufferedReader.readLine();
							System.out.print("Enter college name of Student: ");
							college = bufferedReader.readLine();
							System.out.print("Enter age of student: ");
							marks = Double.parseDouble(bufferedReader.readLine());
							student = new Student(id, name, college, marks);
							studentData.add(student);
							fileHandler.saveToFile(student.toString());
							System.out.println();
						}
						System.out.println("\nCreated List: ");
						System.out.println(studentData);
						System.out.println("***************************************************************\n");
						break;
				
				case "2":studentData=fileHandler.readFromFile();
						System.out.println("\nCreated List: ");
						System.out.println(studentData);
						System.out.println("***************************************************************\n");
						break;

				case "3":System.out.println("Thank you for using this system.");
						System.exit(0);
						break;
						
				default: System.out.println("*********Invalid Option*********");
						break;
			}
		}while(true);
	}

}
