package pkg9_28june;

class Book
{
	
}

public class BookStoreDBSystem 
{

}
