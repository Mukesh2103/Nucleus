package pkg9_28june;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCDemo {

	public static void main(String[] args) 
	{
		Connection con = null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");
//			System.out.println(con);
			
			/*
			 * Retrieve Data from database
			 */
			System.out.println("Retrieve Data from database- ");
			PreparedStatement preparedStatement = con.prepareStatement("select * from book_134");
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				int bookId = resultSet.getInt(1);
				String bookName = resultSet.getString(2);
				double price = resultSet.getDouble(3);
				System.out.println("Book Id: "+bookId+", Book Name: "+bookName+", Price: "+price);
			}
			preparedStatement.close();
			System.out.println("\n*************************************************************************\n");
			
			
			/*
			 * Retrieve Data from database using where clause
			 */
			System.out.println("Retrieve Data from database using where clause- ");
			PreparedStatement preparedStatement1 = con.prepareStatement("select * from book_134 where bookid=?");
			preparedStatement1.setInt(1, 103);
			ResultSet resultSet1 = preparedStatement1.executeQuery();
			while(resultSet1.next())
			{
				int bookId = resultSet1.getInt(1);
				String bookName = resultSet1.getString(2);
				double price = resultSet1.getDouble(3);
				System.out.println("Book Id: "+bookId+", Book Name: "+bookName+", Price: "+price);
			}
			preparedStatement1.close();
			System.out.println("\n*************************************************************************\n");
			
			
			/*
			 * Insert Data into database
			 */
			System.out.println("Insert Data into database- ");
			PreparedStatement preparedStatement2 = con.prepareStatement("insert into book_134 values(?, ?, ?)");
			preparedStatement2.setString(2, "Harry Potter");
			preparedStatement2.setInt(1, 105);
			preparedStatement2.setDouble(3, 1050.50);
			preparedStatement2.executeUpdate();
			System.out.println("Data inserted in the database.");
			preparedStatement2 = con.prepareStatement("select * from book0");
			ResultSet resultSet2 = preparedStatement2.executeQuery();
			while(resultSet2.next())
			{
				int bookId = resultSet2.getInt(1);
				String bookName = resultSet2.getString(2);
				double price = resultSet2.getDouble(3);
				System.out.println("Book Id: "+bookId+", Book Name: "+bookName+", Price: "+price);
			}
			preparedStatement2.close();
			System.out.println("\n*************************************************************************\n");
			
			
			/*
			 * Update existing Data into database
			 */
			/*System.out.println("Update existing Data into database- ");
			PreparedStatement preparedStatement3 = con.prepareStatement("update book_134 set bookname=?, price=? where bookid=?");
			preparedStatement3.setString(1, "Palace of Illusion//Part-2");
			preparedStatement3.setDouble(2, 1550.50);
			preparedStatement3.setInt(3, 104);
			preparedStatement3.executeUpdate();
			System.out.println("Data updated of id=104 in the database.");
			preparedStatement3 = con.prepareStatement("select * from book0");
			ResultSet resultSet3 = preparedStatement3.executeQuery();
			while(resultSet3.next())
			{
				int bookId = resultSet3.getInt(1);
				String bookName = resultSet3.getString(2);
				double price = resultSet3.getDouble(3);
				System.out.println("Book Id: "+bookId+", Book Name: "+bookName+", Price: "+price);
			}
			preparedStatement3.close();
			System.out.println("\n*************************************************************************\n");*/
			
			
			/*
			 * Delete existing Data from database
			 */
			System.out.println("Delete existing Data from database- ");
			PreparedStatement preparedStatement4 = con.prepareStatement("delete from book_134 where bookid=?");
			preparedStatement4.setInt(1, 104);
			preparedStatement4.executeUpdate();
			System.out.println("Data deleted of id=104 from the database.");
			preparedStatement4 = con.prepareStatement("select * from book_134");
			ResultSet resultSet4 = preparedStatement4.executeQuery();
			while(resultSet4.next())
			{
				int bookId = resultSet4.getInt(1);
				String bookName = resultSet4.getString(2);
				double price = resultSet4.getDouble(3);
				System.out.println("Book Id: "+bookId+", Book Name: "+bookName+", Price: "+price);
			}
			preparedStatement4.close();
			System.out.println("\n*************************************************************************\n");
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		finally
		{
			try 
			{
				con.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

}
