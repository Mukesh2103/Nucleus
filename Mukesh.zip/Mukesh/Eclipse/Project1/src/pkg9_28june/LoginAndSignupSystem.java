package pkg9_28june;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

class User
{
	private int id;
	private String name;
	private String email;
	private String password;
	
	public User(String name, String email, String password) 
	{
		this.name = name;
		this.email = email;
		this.password = password;
	}
	public User(int id, String name, String email, String password) 
	{
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public int getId() 
	{
		return id;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public String getName() 
	{
		return name;
	}
	public void setEmail(String email) 
	{
		this.email = email;
	}
	public String getEmail() 
	{
		return email;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	public String getPassword() 
	{
		return password;
	}
	
	public String toString()
	{
		return "Id: "+id+", Name: "+name+", Email: "+email+", Password: "+password;
	}
}

class UserDAO
{
	public int getLastId()
	{
		int lastID = 0;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");
			PreparedStatement preparedStatement = con.prepareStatement("select max(id) as lastID from user_0134");
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
				lastID = resultSet.getInt(1);
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return lastID;
	}
	
	public boolean checkExist(String email)
	{
		boolean present = false;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");
			PreparedStatement preparedStatement = con.prepareStatement("select count(*) as countUsers from user_0134 where email=?");
			preparedStatement.setString(1, email);
			ResultSet resultSet = preparedStatement.executeQuery();
			int userCount = 0;
			if(resultSet.next())
				userCount = resultSet.getInt(1);
			if(userCount>0)
				present = true;
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return present;
	}
	
	public boolean signup(User user)
	{
		boolean signedUp = false;
		user.setId(this.getLastId()+1);
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");
			PreparedStatement preparedStatement = con.prepareStatement("insert into user_0134 values(?, ?, ?, ?)");
			preparedStatement.setInt(1, user.getId());
			preparedStatement.setString(2, user.getName());
			preparedStatement.setString(3, user.getEmail());
			preparedStatement.setString(4, user.getPassword());
			preparedStatement.executeUpdate();
			signedUp = true;
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return signedUp;
	}
	
	public User signin(String email, String password)
	{
		User user = null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl", "sh", "sh");
			PreparedStatement preparedStatement = con.prepareStatement("select * from user_0134 where email=? and password=?");
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
			System.out.println(preparedStatement.toString());
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
				user = new User(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return user;
	}
}

public class LoginAndSignupSystem {

	public static void main(String[] args) 
	{
		UserDAO userDAO = new UserDAO();
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		try {
			do
			{
				System.out.println("******************** Login and Signup System ********************");
				System.out.println("Enter '1': For Signup");
				System.out.println("Enter '2': For Signin");
				System.out.println("Enter '3': For Exit");
				System.out.print("Enter Your Option: ");
				
				String inputOption = bufferedReader.readLine();
				System.out.println("*********************************************************************\n");
				switch(inputOption)
				{
					case "1":System.out.print("Please enter your name: ");
							String name = bufferedReader.readLine();
							System.out.print("Please enter your email: ");
							String email = bufferedReader.readLine();
							if(!userDAO.checkExist(email))
							{
								System.out.print("Please enter your password: ");
								String password = bufferedReader.readLine();
								if(userDAO.signup(new User(name, email, password)))
									System.out.println("Signed Up Successfully.");
							}
							else
								System.out.println("Email Id is already exist. Please go to login page or try with another email id.");
							System.out.println("*********************************************************************\n");
							break;
							
					case "2":System.out.print("Please enter your email: ");
							String email1 = bufferedReader.readLine();
							if(userDAO.checkExist(email1))
							{
								System.out.print("Please enter your password: ");
								String password1 = bufferedReader.readLine();
								User user = userDAO.signin(email1, password1);
								if(user != null)
								{
									System.out.println("Signed In Successfully.");
									System.out.println("Welcome to the System- Hello "+user.getName());
									System.out.println(user);
								}
								else
									System.out.println("Wrong Password!!!!");
							}
							else
								System.out.println("Email Id is not exist. Please register yourself.");
							System.out.println("*********************************************************************\n");
							break;
							
					case "3":System.out.println("Thank you for using this system. We will be waiting for you to come back."); 
							System.exit(0);
							System.out.println("*********************************************************************\n");
							break;
					default: System.out.println("********Invalid Input Option********");
							System.out.println("*********************************************************************\n");
							break;
				}
			}while(true);
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		
		/*if(!userDAO.checkExist("mukeshdewangan01@gmail.com"))
		{
			if(userDAO.signup(new User("Mukesh Dewangan", "mukeshdewangan01@gmail.com", "Mukesh")))
				System.out.println("Signed Up Successfully.");
		}
		else
			System.out.println("Email Id is already exist. Please go to login page or try again with another email id.");
		
		if(userDAO.checkExist("mukeshdewangan01@gmail.com"))
		{
			User user = userDAO.signin("mukeshdewangan01@gmail.com", "Mukesh");
			if(user != null)
			{
				System.out.println("Signed In Successfully.");
				System.out.println(user);
			}
			else
				System.out.println("Wrong Password!!!!");
		}
		else
			System.out.println("Email Id is not exist. Please register yourself.");*/
	}
}
