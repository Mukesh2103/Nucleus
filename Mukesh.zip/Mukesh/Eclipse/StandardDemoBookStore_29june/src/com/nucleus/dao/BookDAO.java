package com.nucleus.dao;

import java.util.List;

import com.nucleus.domain.Book;

public interface BookDAO 
{
	public boolean saveBook(Book book);
	public List<Book> getAllBooks();
	public Book getBookByBookId(int bookId);
	public boolean updateBookDetails(Book book);
	public boolean removeBook(int bookId);
}
