package com.nucleus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.connection.ConnectionSetup;
import com.nucleus.domain.Book;

public class BookDAORDBMSImplementation implements BookDAO 
{

	public boolean saveBook(Book book) 
	{
		ConnectionSetup connectionSetup = null;
		Connection connection = null;
		boolean inserted = false;
		try 
		{
			connectionSetup = new ConnectionSetup();
			connection = connectionSetup.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("insert into standard_book0134 values(?,?,?,?)");
			preparedStatement.setInt(1,book.getBookId());
			preparedStatement.setString(2, book.getBookName());
			preparedStatement.setString(3, book.getIsbnNo());
			preparedStatement.setFloat(4,book.getPrice());
			if(preparedStatement.executeUpdate()>0)
				inserted = true;
			preparedStatement.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			connectionSetup.closeConnection();
		}
		return inserted;
	}

	public List<Book> getAllBooks() 
	{
		ConnectionSetup connectionSetup = null;
		Connection connection = null;
		List<Book> books = null;
		try 
		{
			connectionSetup = new ConnectionSetup();
			connection = connectionSetup.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select * from standard_book0134");
			ResultSet resultSet = preparedStatement.executeQuery();
			books = new ArrayList<Book>();
			Book book;
			while(resultSet.next())
			{
				book = new Book();
				book.setBookId(resultSet.getInt(1));
				book.setBookName(resultSet.getString(2));
				book.setIsbnNo(resultSet.getString(3));
				book.setPrice(resultSet.getFloat(4));
				books.add(book);
			}
			preparedStatement.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			connectionSetup.closeConnection();
		}
		return books;
	}

	public Book getBookByBookId(int bookId) 
	{
		ConnectionSetup connectionSetup = null;
		Connection connection = null;
		Book book = null;
		try 
		{
			connectionSetup = new ConnectionSetup();
			connection=connectionSetup.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select * from standard_book0134 where id=?");
			preparedStatement.setInt(1, bookId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				book = new Book();
				book.setBookId(resultSet.getInt(1));
				book.setBookName(resultSet.getString(2));
				book.setIsbnNo(resultSet.getString(3));
				book.setPrice(resultSet.getFloat(4));
			}
			preparedStatement.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			connectionSetup.closeConnection();
		}
		return book;
	}

	public boolean updateBookDetails(Book book) 
	{
		ConnectionSetup connectionSetup = null;
		Connection connection = null;
		boolean updated = false;
		try 
		{
			connectionSetup = new ConnectionSetup();
			connection=connectionSetup.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("update standard_book0134 set booktitle=?, isbn=?, price=? where id=?");
			preparedStatement.setString(1, book.getBookName());
			preparedStatement.setString(2, book.getIsbnNo());
			preparedStatement.setFloat(3, book.getPrice());
			preparedStatement.setInt(4, book.getBookId());
			if(preparedStatement.executeUpdate()>0)
				updated = true;
			preparedStatement.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			connectionSetup.closeConnection();
		}
		return updated;
	}

	public boolean removeBook(int bookId) 
	{
		ConnectionSetup connectionSetup = null;
		Connection connection = null;
		boolean removed = false;
		try 
		{
			connectionSetup = new ConnectionSetup();
			connection=connectionSetup.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("delete from standard_book0134 where id=?");
			preparedStatement.setInt(1, bookId);
			if(preparedStatement.executeUpdate()>0)
				removed = true;
			preparedStatement.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			connectionSetup.closeConnection();
		}
		return removed;
	}

	public int getNewBookId()
	{
		int lastBookID = 0;
		ConnectionSetup connectionSetup = null;
		try 
		{
			connectionSetup = new ConnectionSetup();
			Connection connection = connectionSetup.getConnection();
			
			PreparedStatement preparedStatement = connection.prepareStatement("select max(id) as lastID from standard_book0134");
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
				lastBookID = resultSet.getInt(1);
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			connectionSetup.closeConnection();
		}
		++lastBookID;
		return lastBookID;
	}

	public boolean checkBookIsbnExistence(String isbnNo)
	{
		ConnectionSetup connectionSetup = null;
		Connection connection = null;
		boolean bookExistWithIsbn = false;
		try 
		{
			connectionSetup = new ConnectionSetup();
			connection=connectionSetup.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select count(*) as bookCount from standard_book0134 where isbn=?");
			preparedStatement.setString(1, isbnNo);
			ResultSet resultSet = preparedStatement.executeQuery();
			int bookCount = 0;
			if(resultSet.next())
				bookCount = resultSet.getInt(1);
			if(bookCount>0)
				bookExistWithIsbn = true;
			preparedStatement.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			connectionSetup.closeConnection();
		}
		return bookExistWithIsbn;
	}
	
}
