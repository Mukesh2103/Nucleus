package com.nucleus.domain;

public class Book 
{
	private int bookId;
	private String bookName;
	private String isbnNo;
	private float price;
	public int getBookId() 
	{
		return bookId;
	}
	public void setBookId(int bookId) 
	{
		this.bookId = bookId;
	}
	public String getBookName() 
	{
		return bookName;
	}
	public void setBookName(String bookName) 
	{
		this.bookName = bookName;
	}
	public String getIsbnNo() 
	{
		return isbnNo;
	}
	public void setIsbnNo(String isbnNo) 
	{
		this.isbnNo = isbnNo;
	}
	public float getPrice() 
	{
		return price;
	}
	public void setPrice(float price) 
	{
		this.price = price;
	}
	public String toString() 
	{
		return "Book [bookId=" + bookId + ", bookName=" + bookName
				+ ", isbnNo=" + isbnNo + ", price=" + price + "]";
	}
	
}
