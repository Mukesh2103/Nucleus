package com.nucleus.execution;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.nucleus.dao.BookDAORDBMSImplementation;
import com.nucleus.domain.Book;

public class Execution {

	public static void main(String[] args) 
	{
		BookDAORDBMSImplementation bookDAORDBMSImplementation = new BookDAORDBMSImplementation();
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		
		try
		{
			do
			{
				System.out.println("******************** Book Store System ********************");
				System.out.println("Enter '1': to enter new book data.");
				System.out.println("Enter '2': to display all book data.");
				System.out.println("Enter '3': to display book data by id.");
				System.out.println("Enter '4': to update book data.");
				System.out.println("Enter '5': to delete book data.");
				System.out.println("Enter '6': to exit the system.");
				System.out.print("Enter Your Option: ");
				
				String inputOption = bufferedReader.readLine();
				System.out.println("*********************************************************************\n");
				switch(inputOption)
				{
					case "1":System.out.println("Enter new book data-");
							System.out.print("Please enter book name: ");
							String bookName = bufferedReader.readLine();
							System.out.print("Please enter book isbn: ");
							String isbnNo = bufferedReader.readLine();
							System.out.print("Please enter book price: ");
							float price = Float.parseFloat(bufferedReader.readLine());
							if(!bookDAORDBMSImplementation.checkBookIsbnExistence(isbnNo))
							{
								Book book = new Book();
								book.setBookId(bookDAORDBMSImplementation.getNewBookId());
								book.setBookName(bookName);
								book.setIsbnNo(isbnNo);
								book.setPrice(price);
								if(bookDAORDBMSImplementation.saveBook(book))
									System.out.println("Book Saved Successfully.");
							}
							else
								System.out.println("Book is already exist with ISBN: "+isbnNo+". Please check book details.");
							System.out.println("*********************************************************************\n");
							break;
							
					case "2":System.out.println("Display all book data-");
							List<Book> books = bookDAORDBMSImplementation.getAllBooks();
							System.out.println("Book Details: ");
							for(Book book1:books)
							{
								System.out.println(book1);
							}
							System.out.println("*********************************************************************\n");
							break;
							
					case "3":System.out.println("Display book data by id-");
							System.out.print("Please enter book id: ");
							int bookId = Integer.parseInt(bufferedReader.readLine());
							Book book = bookDAORDBMSImplementation.getBookByBookId(bookId);
							System.out.println("Book Details of book id: "+bookId);
							System.out.println(book);
							break;
							
					case "4":System.out.println("Update book data-");
							System.out.print("Please enter book id: ");
							int bookId2 = Integer.parseInt(bufferedReader.readLine());
							Book book1 = bookDAORDBMSImplementation.getBookByBookId(bookId2);
							if(book1 != null)
							{
								String temp = null;
								System.out.print("Do you want to edit book name [y/Y]: ");
								temp = bufferedReader.readLine();
								if(temp.equalsIgnoreCase("y"))
								{
									System.out.print("Please enter new name to update: ");
									String newBookName = bufferedReader.readLine();
									book1.setBookName(newBookName);
								}
								
								temp = null;
								System.out.print("Do you want to edit book isbn no. [y/Y]: ");
								temp = bufferedReader.readLine();
								if(temp.equalsIgnoreCase("y"))
								{
									System.out.print("Please enter new isbn no. to update: ");
									String newIsbnNo = bufferedReader.readLine();
									if(bookDAORDBMSImplementation.checkBookIsbnExistence(newIsbnNo))
										book1.setIsbnNo(newIsbnNo);
									else
										System.out.println("Book is already present with isbn no.: "+newIsbnNo+". Please check the record.");
								}
								
								temp = null;
								System.out.print("Do you want to edit book price [y/Y]: ");
								temp = bufferedReader.readLine();
								if(temp.equalsIgnoreCase("y"))
								{
									System.out.print("Please enter new price to update: ");
									Float newPrice = Float.parseFloat(bufferedReader.readLine());
									book1.setPrice(newPrice);
								}
								if(bookDAORDBMSImplementation.updateBookDetails(book1))
									System.out.println("Book Details updated successfully.");
							}
							else
								System.out.println("Book is not present with id: "+bookId2);
							System.out.println("*********************************************************************\n");
							break;
							
					case "5":System.out.println("Delete book data-");
							System.out.print("Please enter book id: ");
							int bookId1 = Integer.parseInt(bufferedReader.readLine());
							if(bookDAORDBMSImplementation.removeBook(bookId1))
								System.out.println("Book Data Removed.");
							else
								System.out.println("Book is not present with id: "+bookId1);
							break;
							
					case "6":System.out.println("Enter new book data-");
							System.out.println("Thank you for using this system. We will be waiting for you to come back."); 
							System.exit(0);
							System.out.println("*********************************************************************\n");
							break;
					default: System.out.println("********Invalid Input Option********");
							System.out.println("*********************************************************************\n");
							break;
				}
			}while(true);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
