package pkg6_25june;

public class ExceptionHandling 
{
	public static void main(String[] args) 
	{
		System.out.println("Calculation: ");
		try
		{
			int a = 10/0;			//This will give ArithmeticException
			System.out.println(a);
			String str = null;		
			System.out.println(str.length());	//This will give NullPointerException
			int[] arr = new int[2];
			arr[2] = 5;					//This will give ArrayIndexOutOfBoundException
		}
		catch(ArithmeticException e)	//This will handle the ArithmeticException
		{
			System.out.println(e);
			System.out.println("Number is not divisible by 0.");
			e.printStackTrace();
		}
		catch(NullPointerException e)	//This will handle the NullPointerException
		{
			System.out.println(e);
			System.out.println("String is not initialized. String is null.");
			e.printStackTrace();
		}
		catch(Exception e)	//This will handle the Exception if any other Exception occurs such as ArrayIndexOutOfBoundException
		{
			System.out.println(e);
			System.out.println("Main parent exception class.");
			e.printStackTrace();
		}
		System.out.println("End");
	}
}
