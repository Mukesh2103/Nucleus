package pkg6_25june;

public class ExceptionHandlingDemo2 {
	public static void myMethod()
	{
		int a = 10;
		int b = 1;
		if(b == 0)
			throw new ArithmeticException();	//This will throw the ArithmeticException explicitly.
		else
			System.out.println("Result: "+(a/b));
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Calculation: ");
		try
		{
			myMethod();
		}
		catch(ArithmeticException e)			//This will handle the thrown ArithmeticException
		{
			System.out.println("Divisor should be greater than 0.");
		}
		System.out.println("End");
	}
}
