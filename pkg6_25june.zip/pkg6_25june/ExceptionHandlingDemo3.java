package pkg6_25june;

public class ExceptionHandlingDemo3 {

	public static void myMethod()
	{
		int a = 10/10;
		System.out.println(a);
		String str = null;
		System.out.println(str.length());
		int[] arr = new int[2];
		arr[2] = 5;
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Calculation: ");
		try
		{
			myMethod();
		}
		/*catch(ArithmeticException e)
		{
			System.out.println(e);
			System.out.println("Number is not divisible by 0.");
			e.printStackTrace();
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
			System.out.println("String is not initialized. String is null.");
			e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("Main parent exception class.");
			e.printStackTrace();
		}*/
		finally					//Finally method will always executed.
		{
			System.out.println("Finally Method executed.");
		}
		System.out.println("End");
	}

}
