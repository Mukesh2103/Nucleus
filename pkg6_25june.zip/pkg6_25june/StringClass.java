package pkg6_25june;

class Account
{
	private int accNo;
	private String accName;
	public Account(int accNo, String accName)
	{
		this.accNo = accNo;
		this.accName = accName;
	}
	
	//This method will override the toString() method of object class and return the values in string format.
	/*public String toString()
	{
		return "Account No.: "+accNo+" and Account Name: "+accName;
	}*/
}

public class StringClass 
{
	public static void main(String[] args) 
	{	
		Account a1 = new Account(1234567890, "Mukesh");
		System.out.println(a1);				//Implicitly called the toString() method.
		System.out.println(a1.toString());	//Explicitly called
	}
}
